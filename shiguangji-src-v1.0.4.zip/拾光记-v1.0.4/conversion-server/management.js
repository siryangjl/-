'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-File-Name',
};

function tokenHash(token) {
  return crypto.createHash('sha256').update(token || '').digest('hex').slice(0, 16);
}

function emailHash16(email) {
  return crypto.createHash('sha256').update(String(email || '').toLowerCase().trim()).digest('hex').slice(0, 16);
}

function safeEqual(a, b) {
  const pa = String(a || '');
  const pb = String(b || '');
  if (pa.length !== pb.length) return false;
  return crypto.timingSafeEqual(Buffer.from(pa), Buffer.from(pb));
}

const LOGIN_MAX_FAILS = 5;
const LOGIN_LOCK_MS = 15 * 60 * 1000;
const loginAttempts = new Map();

function clientIp(req) {
  const cf = req.headers['cf-connecting-ip'];
  if (cf) return String(cf).split(',')[0].trim();
  return (req.socket && req.socket.remoteAddress) || 'unknown';
}

function loginThrottleState(ip) {
  const now = Date.now();
  const rec = loginAttempts.get(ip) || { fails: 0, lockedUntil: 0 };
  if (rec.lockedUntil && now >= rec.lockedUntil) {
    rec.fails = 0;
    rec.lockedUntil = 0;
  }
  return rec;
}

function noteLoginFailure(ip) {
  const now = Date.now();
  const rec = loginThrottleState(ip);
  rec.fails += 1;
  if (rec.fails >= LOGIN_MAX_FAILS) {
    rec.lockedUntil = now + LOGIN_LOCK_MS;
    rec.fails = 0;
  }
  loginAttempts.set(ip, rec);
}

function clearLoginThrottle(ip) {
  loginAttempts.delete(ip);
}

const AUDIT_MAX_BYTES = 1024 * 1024;
function appendAudit(workDir, entry) {
  try {
    if (!workDir) return;
    const file = path.join(workDir, 'audit.log');
    let stat = null;
    try { stat = fs.statSync(file); } catch (_) {}
    if (stat && stat.size >= AUDIT_MAX_BYTES) {
      fs.renameSync(file, file + '.1');
    }
    const line = JSON.stringify(Object.assign({ ts: new Date().toISOString() }, entry)) + '\n';
    fs.appendFileSync(file, line, 'utf8');
  } catch (_) {}
}

function readDevicesFile(devicesFile) {
  try {
    return JSON.parse(fs.readFileSync(devicesFile, 'utf8'));
  } catch (_) {
    return {};
  }
}

function json(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, Object.assign({
    'Content-Type': 'application/json; charset=utf-8',
    'X-Content-Type-Options': 'nosniff',
    'Cache-Control': 'no-store',
  }, CORS));
  res.end(body);
}

function isAdminToken(authHeader, adminToken) {
  if (!adminToken) return false;
  const m = /^Bearer\s+(.+)$/.exec(String(authHeader || ''));
  return !!m && safeEqual(m[1].trim(), adminToken);
}

function isDeviceToken(authHeader, devices) {
  const m = /^Bearer\s+(.+)$/.exec(String(authHeader || ''));
  if (!m) return false;
  const token = m[1].trim();
  return Object.values(devices).some(d => safeEqual(d.token, token));
}

function receiveToFile(req, targetPath, maxBytes) {
  return new Promise((resolve, reject) => {
    const ws = fs.createWriteStream(targetPath);
    let size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > maxBytes) {
        req.destroy();
        reject(new Error('文件过大'));
        return;
      }
      if (!ws.write(chunk)) req.pause();
    });
    ws.on('drain', () => req.resume());
    req.on('end', () => ws.end());
    ws.on('finish', () => resolve(size));
    req.on('error', err => {
      ws.destroy();
      try { fs.rmSync(targetPath, { force: true }); } catch (_) {}
      reject(err);
    });
    ws.on('error', err => {
      try { fs.rmSync(targetPath, { force: true }); } catch (_) {}
      reject(err);
    });
  });
}

function listDirBackups(dir) {
  try {
    return fs.readdirSync(dir)
      .filter(f => /^backup-.*\.json$/.test(f))
      .map(f => {
        const stat = fs.statSync(path.join(dir, f));
        const backupId = f.replace(/^backup-/, '').replace(/\.json$/, '');
        return { backupId, fileName: f, size: stat.size, savedAt: stat.mtime.toISOString() };
      })
      .sort((a, b) => b.savedAt.localeCompare(a.savedAt));
  } catch (_) {
    return [];
  }
}

function listDeviceBackups(backupDir, token) {
  return listDirBackups(path.join(backupDir, tokenHash(token)));
}

function listAccountBackups(backupDir, email) {
  return listDirBackups(accountDirPath(backupDir, email));
}

function summarizeAccount(email, account, backupDir) {
  const backups = listAccountBackups(backupDir, email);
  return {
    email,
    emailHash: emailHash16(email),
    tokenHash: tokenHash(account.token),
    createdAt: account.createdAt,
    lastSeenAt: account.lastSeenAt,
    backupCount: backups.length,
    lastBackupAt: backups.length ? backups[0].savedAt : null,
  };
}

function summarizeDevice(deviceId, record, backupDir) {
  const backups = listDeviceBackups(backupDir, record.token);
  return {
    deviceId,
    tokenHash: tokenHash(record.token),
    createdAt: record.createdAt,
    lastSeenAt: record.lastSeenAt,
    backupCount: backups.length,
    lastBackupAt: backups.length ? backups[0].savedAt : null,
  };
}

function readBindings(bindingsFile) {
  try {
    return JSON.parse(fs.readFileSync(bindingsFile, 'utf8'));
  } catch (_) {
    return {};
  }
}

function readAccountsFile(accountsFile) {
  try {
    return JSON.parse(fs.readFileSync(accountsFile, 'utf8'));
  } catch (_) {
    return {};
  }
}

function isAccountToken(authHeader, accountsFile) {
  const m = /^Bearer\s+(.+)$/.exec(String(authHeader || ''));
  if (!m) return false;
  const token = m[1].trim();
  const accounts = accountsFile ? readAccountsFile(accountsFile) : {};
  return Object.keys(accounts).some(email => {
    const a = accounts[email];
    return a && a.token && safeEqual(a.token, token);
  });
}

function accountDirPath(backupDir, email) {
  return path.join(backupDir, 'acct-' + emailHash16(email));
}

function boundEmailsByDevice(bindingsFile) {
  const map = {};
  const bindings = readBindings(bindingsFile);
  for (const email of Object.keys(bindings || {})) {
    const deviceId = bindings[email];
    if (!deviceId) continue;
    (map[deviceId] = map[deviceId] || []).push(email);
  }
  return map;
}

function handleManagement(ctx, req, res, url) {
  const { workDir, devicesFile, bindingsFile, accountsFile, backupDir, releasesDir, adminToken, maxUploadBytes, adminPagePath } = ctx;
  const method = req.method;
  const pathname = decodeURIComponent(url.pathname);

  if (method === 'OPTIONS') {
    res.writeHead(204, CORS);
    res.end();
    return true;
  }

  // 管理网页
  if (method === 'GET' && (pathname === '/admin' || pathname === '/admin/')) {
    try {
      const html = fs.readFileSync(adminPagePath, 'utf8');
      res.writeHead(200, {
        'Content-Type': 'text/html; charset=utf-8',
        'X-Content-Type-Options': 'nosniff',
        'Referrer-Policy': 'no-referrer',
        'Cache-Control': 'no-store',
        ...CORS,
      });
      res.end(html);
    } catch (err) {
      json(res, 500, { error: '管理页面不可用：' + err.message });
    }
    return true;
  }

  // 更新检查（设备或总指挥 token）
  if (method === 'GET' && (pathname === '/v1/update/latest' || pathname === '/v1/update/check')) {
    const devices = readDevicesFile(devicesFile);
    const auth = req.headers['authorization'] || '';
    if (!isAdminToken(auth, adminToken) && !isDeviceToken(auth, devices) && !isAccountToken(auth, accountsFile)) {
      appendAudit(workDir, { type: 'update-unauthorized', ip: clientIp(req), path: pathname, reason: '无效或缺失令牌' });
      json(res, 401, { error: '未授权的请求' });
      return true;
    }
    const latestFile = path.join(releasesDir, 'latest.json');
    try {
      const latest = JSON.parse(fs.readFileSync(latestFile, 'utf8'));
      json(res, 200, { ok: true, latest });
    } catch (_) {
      json(res, 200, { ok: true, latest: null });
    }
    return true;
  }

  // APK 下载
  if (method === 'GET' && pathname === '/v1/update/download') {
    const devices = readDevicesFile(devicesFile);
    const auth = req.headers['authorization'] || '';
    if (!isAdminToken(auth, adminToken) && !isDeviceToken(auth, devices) && !isAccountToken(auth, accountsFile)) {
      appendAudit(workDir, { type: 'update-unauthorized', ip: clientIp(req), path: pathname, reason: '无效或缺失令牌' });
      json(res, 401, { error: '未授权的请求' });
      return true;
    }
    const latestFile = path.join(releasesDir, 'latest.json');
    let latest = null;
    try {
      latest = JSON.parse(fs.readFileSync(latestFile, 'utf8'));
    } catch (_) {}
    let fileName = null;
    const wanted = url.searchParams.get('fileName');
    if (wanted) {
      fileName = path.basename(String(wanted).replace(/\\/g, '/'));
      if (path.join(releasesDir, fileName).indexOf(path.join(releasesDir)) !== 0) {
        json(res, 400, { error: '无效的文件名' });
        return true;
      }
    }
    if (!fileName) {
      if (!latest || !latest.fileName) {
        json(res, 404, { error: '暂无可用安装包' });
        return true;
      }
      fileName = latest.fileName;
    }
    const apkPath = path.join(releasesDir, fileName);
    if (!fs.existsSync(apkPath)) {
      json(res, 404, { error: '安装包文件缺失' });
      return true;
    }
    res.writeHead(200, {
      'Content-Type': 'application/vnd.android.package-archive',
      'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(fileName)}`,
      'Content-Length': fs.statSync(apkPath).size,
      ...CORS,
    });
    fs.createReadStream(apkPath).pipe(res);
    return true;
  }

  // ---- 总指挥管理接口 ----
  if (pathname === '/v1/admin/login' && method === 'POST') {
    if (!adminToken) {
      appendAudit(workDir, { type: 'admin-login-denied', ip: clientIp(req), reason: '口令未配置' });
      json(res, 503, { error: '总指挥口令未配置' });
      return true;
    }
    const ip = clientIp(req);
    const state = loginThrottleState(ip);
    if (state.lockedUntil) {
      appendAudit(workDir, { type: 'admin-login-locked', ip, reason: '锁定期内拒绝' });
      json(res, 429, { error: '尝试次数过多，请稍后再试' });
      return true;
    }
    receiveToFile(req, path.join(workDir, 'admin-login.tmp'), 8 * 1024)
      .then(size => {
        const raw = fs.readFileSync(path.join(workDir, 'admin-login.tmp'), 'utf8');
        try { fs.rmSync(path.join(workDir, 'admin-login.tmp'), { force: true }); } catch (_) {}
        let token = '';
        try { token = JSON.parse(raw).token || ''; } catch (_) {}
        if (safeEqual(token, adminToken)) {
          clearLoginThrottle(ip);
          appendAudit(workDir, { type: 'admin-login-ok', ip });
          json(res, 200, { ok: true });
        } else {
          noteLoginFailure(ip);
          appendAudit(workDir, { type: 'admin-login-fail', ip, reason: '口令错误' });
          json(res, 401, { error: '口令错误' });
        }
      })
      .catch(err => {
        appendAudit(workDir, { type: 'admin-login-err', ip, reason: err.message });
        json(res, 400, { error: err.message });
      });
    return true;
  }

  if (pathname.startsWith('/v1/admin/')) {
    const auth = req.headers['authorization'] || '';
    if (!isAdminToken(auth, adminToken)) {
      appendAudit(workDir, { type: 'admin-unauthorized', ip: clientIp(req), path: pathname, reason: '无效或缺失令牌' });
      json(res, 401, { error: '未授权，请重新登录' });
      return true;
    }

    if (method === 'GET' && pathname === '/v1/admin/devices') {
      const devices = readDevicesFile(devicesFile);
      const emailByDevice = bindingsFile ? boundEmailsByDevice(bindingsFile) : {};
      const list = Object.keys(devices).map(deviceId =>
        Object.assign(summarizeDevice(deviceId, devices[deviceId], backupDir), {
          boundEmails: emailByDevice[deviceId] || [],
        })
      ).sort((a, b) => String(b.lastSeenAt).localeCompare(String(a.lastSeenAt)));
      json(res, 200, { ok: true, devices: list });
      return true;
    }

    // 单设备详情（含备份列表）
    const deviceMatch = pathname.match(/^\/v1\/admin\/devices\/([^/]+)$/);
    if (method === 'GET' && deviceMatch) {
      const deviceId = decodeURIComponent(deviceMatch[1]);
      const devices = readDevicesFile(devicesFile);
      const record = devices[deviceId];
      if (!record) {
        json(res, 404, { error: '设备不存在' });
        return true;
      }
      json(res, 200, Object.assign({ ok: true }, summarizeDevice(deviceId, record, backupDir), {
        boundEmails: (bindingsFile ? boundEmailsByDevice(bindingsFile) : {})[deviceId] || [],
        backups: listDeviceBackups(backupDir, record.token),
      }));
      return true;
    }

    // 读取某设备某个备份内容
    const backupMatch = pathname.match(/^\/v1\/admin\/devices\/([^/]+)\/backups\/([^/]+)$/);
    if (method === 'GET' && backupMatch) {
      const deviceId = decodeURIComponent(backupMatch[1]);
      const backupId = decodeURIComponent(backupMatch[2]);
      const devices = readDevicesFile(devicesFile);
      const record = devices[deviceId];
      if (!record) {
        json(res, 404, { error: '设备不存在' });
        return true;
      }
      if (!/^[a-f0-9]+$/.test(backupId)) {
        json(res, 400, { error: '无效备份标识' });
        return true;
      }
      const backupPath = path.join(backupDir, tokenHash(record.token), `backup-${backupId}.json`);
      try {
        const raw = JSON.parse(fs.readFileSync(backupPath, 'utf8'));
        const meta = raw.backupMeta || { entries: 0, attachments: 0, exportDrafts: 0, exportAttachments: 0 };
        json(res, 200, {
          ok: true,
          deviceId,
          backupId,
          savedAt: raw.exportedAt || null,
          meta,
          data: raw,
        });
      } catch (_) {
        json(res, 404, { error: '备份内容不可用或不存在' });
      }
      return true;
    }

    // 邮箱账号列表（主模型展示）
    if (method === 'GET' && pathname === '/v1/admin/accounts') {
      const map = accountsFile ? readAccountsFile(accountsFile) : {};
      const bindings = bindingsFile ? readBindings(bindingsFile) : {};
      const list = Object.keys(map).map(email =>
        Object.assign(summarizeAccount(email, map[email], backupDir), {
          legacyDeviceId: bindings[email] || null,
        })
      ).sort((a, b) => String(b.lastSeenAt).localeCompare(String(a.lastSeenAt)));
      json(res, 200, { ok: true, accounts: list });
      return true;
    }

    // 单邮箱账号详情
    const accountMatch = pathname.match(/^\/v1\/admin\/accounts\/([^/]+)$/);
    if (method === 'GET' && accountMatch) {
      const email = decodeURIComponent(accountMatch[1]).toLowerCase().trim();
      const map = accountsFile ? readAccountsFile(accountsFile) : {};
      const account = map[email];
      if (!account) {
        json(res, 404, { error: '邮箱账号不存在' });
        return true;
      }
      const bindings = bindingsFile ? readBindings(bindingsFile) : {};
      json(res, 200, Object.assign({ ok: true }, summarizeAccount(email, account, backupDir), {
        legacyDeviceId: bindings[email] || null,
        backups: listAccountBackups(backupDir, email),
      }));
      return true;
    }

    // 读取某邮箱账号某个备份内容
    const accountBackupMatch = pathname.match(/^\/v1\/admin\/accounts\/([^/]+)\/backups\/([^/]+)$/);
    if (method === 'GET' && accountBackupMatch) {
      const email = decodeURIComponent(accountBackupMatch[1]).toLowerCase().trim();
      const backupId = decodeURIComponent(accountBackupMatch[2]);
      const map = accountsFile ? readAccountsFile(accountsFile) : {};
      if (!map[email]) {
        json(res, 404, { error: '邮箱账号不存在' });
        return true;
      }
      if (!/^[a-f0-9]+$/.test(backupId)) {
        json(res, 400, { error: '无效备份标识' });
        return true;
      }
      const backupPath = path.join(accountDirPath(backupDir, email), `backup-${backupId}.json`);
      try {
        const raw = JSON.parse(fs.readFileSync(backupPath, 'utf8'));
        const meta = raw.backupMeta || { entries: 0, attachments: 0, exportDrafts: 0, exportAttachments: 0 };
        json(res, 200, {
          ok: true,
          email,
          backupId,
          savedAt: raw.exportedAt || null,
          meta,
          data: raw,
        });
      } catch (_) {
        json(res, 404, { error: '备份内容不可用或不存在' });
      }
      return true;
    }

    // 发布新版本：PUT 上传 APK，元数据在查询参数
    if (method === 'PUT' && pathname === '/v1/admin/release') {
      fs.mkdirSync(releasesDir, { recursive: true });
      const versionCode = String(url.searchParams.get('versionCode') || '').trim();
      const versionName = String(url.searchParams.get('versionName') || '').trim();
      const notes = String(url.searchParams.get('notes') || '').trim();
      if (!versionCode || !/^\d+$/.test(versionCode)) {
        json(res, 400, { error: '缺少有效的 versionCode' });
        return true;
      }
      if (!versionName) {
        json(res, 400, { error: '缺少 versionName' });
        return true;
      }
      const fileName = `shiguangji-${versionName}-${versionCode}.apk`;
      const target = path.join(releasesDir, fileName);
      receiveToFile(req, target, maxUploadBytes)
        .then(size => {
          const latest = {
            versionCode: Number(versionCode),
            versionName,
            fileName,
            notes,
            size,
            publishedAt: new Date().toISOString(),
          };
          fs.writeFileSync(path.join(releasesDir, 'latest.json'), JSON.stringify(latest, null, 2));
          json(res, 200, { ok: true, latest });
        })
        .catch(err => json(res, 400, { error: '发布失败：' + err.message }));
      return true;
    }

    json(res, 404, { error: '管理接口不存在' });
    return true;
  }

  return false;
}

module.exports = { handleManagement, tokenHash, safeEqual, appendAudit };
