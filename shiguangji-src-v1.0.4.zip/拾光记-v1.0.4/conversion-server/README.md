# 拾光记 Word→PDF 转换服务

零依赖 Node.js 服务，用 LibreOffice headless 将 Word 文档转换为 PDF，最大程度保留原排版。
API 与「拾光记」App 内置的调用约定完全兼容。

## 接口

### App 端（账号令牌 / CONVERSION_TOKEN 鉴权）

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /v1/jobs | 上传 docx（body 即二进制），头 `X-File-Name` 传文件名，返回 `{jobId}` |
| GET | /v1/jobs/:id | 轮询进度，返回 `{jobId,status,progress,stage,error}` |
| GET | /v1/jobs/:id/result | 下载转换后的 PDF |
| DELETE | /v1/jobs/:id | 取消任务 |
| GET | /v1/backup/status | 连接健康检查 |
| PUT | /v1/backup | 保存备份 JSON（按账号/设备归属目录） |
| GET | /v1/backup/latest | 拉取当前账号最新备份 |
| POST | /v1/device/register | 仅兼容旧版 App：注册设备令牌（新 App 不再调用） |
| POST | /v1/auth/send-code | 发送邮箱验证码，body `{email}`（免鉴权，需 SMTP） |
| POST | /v1/auth/login | 邮箱验证码登录，body `{email,code}`；返回稳定账号令牌；首次 `bound` / 已存在 `login` / 迁移过旧设备 `migrated` |

鉴权：请求头 `Authorization: Bearer <账号令牌 | CONVERSION_TOKEN | 遗留设备令牌>`。
账号令牌由邮箱验证码登录签发且长期稳定；云端备份按邮箱账号目录（`$BACKUP_DIR/acct-<sha256(email)>`）归属，换机/重装用同一邮箱登录即回到同一份数据，与具体设备无关。

### 邮箱账号存储模型

- 邮箱是云端数据的唯一归属：登录只提交 `{email, code}`，验证通过后服务端签发长期稳定的账号令牌并返回。
- 备份统一存到该邮箱的账号目录 `$BACKUP_DIR/acct-<sha256(email)前16位>`；App 同步、管理端查询都只认账号令牌。
- 服务端不再记录手机标识（如 ANDROID_ID）作为归属依据；`email-bindings.json`、遗留设备目录只用于老版本的一次性迁移。
- 迁移：老版本设备完成过邮箱绑定，登录同一邮箱时，该邮箱名下旧设备的全部备份文件整体 `rename` 并入账号目录，随后删除旧设备记录与绑定，审计记录 `device-migrate-ok`。
- 旧版 App（还会带 `deviceId` 登录/注册）发送的备份会经账号目录解析后合并进账号名下，兼容过渡期。
- 新 App：打开即自动连接服务端地址（打包进安装包），未登录时备份仅在本机；首次登录后每次变更自动同步到账号目录。
- 未配置 SMTP 时邮箱登录不可用，此时可退回 `CONVERSION_TOKEN` 做全局只读访问。

### 管理端（ADMIN_TOKEN 鉴权）

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /admin | 指挥端管理网页 |
| POST | /v1/admin/login | 登录校验，body `{token}` 与 ADMIN_TOKEN 比对 |
| GET | /v1/admin/accounts | 邮箱账号列表（含各账号备份统计） |
| GET | /v1/admin/accounts/:email | 单个账号详情（含 token/email 哈希摘要） |
| GET | /v1/admin/accounts/:email/backups/:backupId | 读取该账号某次备份内容 |
| GET | /v1/admin/devices | 历史设备列表（遗留只读追溯） |
| GET | /v1/admin/devices/:id/backups/:backupId | 读取某遗留设备备份内容 |
| PUT | /v1/admin/release | 发布新版 APK（参数在 query） |
| GET | /v1/update/latest, /v1/update/check | App 更新检查 |
| GET | /v1/update/download | App 下载安装包 |

管理接口其余请求一律带 `Authorization: Bearer <ADMIN_TOKEN>`。

## 本地运行

```bash
node server.js
```

环境变量：

| 变量 | 默认 | 说明 |
|------|------|------|
| PORT | 31876 | 监听端口 |
| CONVERSION_TOKEN | 空 | 转换鉴权 Token（建议必设） |
| ADMIN_TOKEN | 空 | 管理接口 Token，不设则管理页 503 |
| WORK_DIR | 系统临时目录 | 任务与备份的存储目录 |
| MAX_UPLOAD_MB | 200 | 单文件上传上限（MB） |
| JOBS_TTL_MIN | 60 | 任务过期时间（分钟） |
| BACKUP_DIR | $WORK_DIR/backups | 备份文件存储目录 |
| DEVICES_FILE | $WORK_DIR/devices.json | 遗留设备注册表（仅旧 App 与迁移用） |
| BINDINGS_FILE | $WORK_DIR/email-bindings.json | 遗留邮箱-设备绑定表（仅旧 App 迁移用） |
| ACCOUNTS_FILE | $WORK_DIR/accounts.json | 邮箱账号表（新模型，含账号令牌哈希与创建/最近登录时间） |
| RELEASES_DIR | $WORK_DIR/releases | App 更新包目录 |
| SMTP_HOST | smtp.qq.com | 验证码邮件 SMTP 服务器 |
| SMTP_PORT | 465 | SMTP 端口 |
| SMTP_MODE | ssl | ssl / starttls / plain |
| SMTP_USER | 空 | QQ 邮箱地址（用于发信） |
| SMTP_PASS | 空 | QQ 邮箱授权码（非登录密码） |
| SMTP_FROM | 同 SMTP_USER | 发件人地址 |
| SMTP_ALLOW_INSECURE | 0 | 允许明文 SMTP（仅测试用） |

> 不配置 SMTP_USER / SMTP_PASS 时，`/v1/auth/send-code` 与 `/v1/auth/login` 返回 503，不影响转换与备份功能。
> QQ 邮箱需先在「设置 → 账户 → 开启 SMTP 服务」生成授权码，再用该授权码作为 SMTP_PASS。

## 安全加固

- 令牌比对使用 `crypto.timingSafeEqual`，避免时序侧信道。
- `/v1/admin/login` 同一来源连续失败 5 次锁定 15 分钟（每客户端 IP 计数，取 Cloudflare 回传头 `CF-Connecting-IP`，否则用 socket 地址）。
- `/v1/device/register` 每客户端 IP 每小时限 10 次，防止设备表被灌满。
- 响应统一加 `X-Content-Type-Options: nosniff` 与 `Cache-Control: no-store`。
- 审计日志：每次失败登录 / 锁定拒绝 / 登录成功 / 未授权请求都会追加一行 JSON 到工作目录 `audit.log`（与 devices.json 同目录），单文件超 1 MB 自动轮转为 `audit.log.1`。

### 审计日志事件

写入工作目录（Docker 部署即挂载卷内，本机查看 `audit.log` / `audit.log.1`）：

| 事件 | 含义 |
| --- | --- |
| `admin-login-fail` | 管理口令错误 |
| `admin-login-ok` | 管理口令正确、登录成功 |
| `admin-login-locked` | 锁定期内被拒绝 |
| `admin-login-denied` | 服务未配置 ADMIN_TOKEN，登录入口被拒 |
| `admin-login-err` | 登录请求体读取异常 |
| `admin-unauthorized` | 管理接口携带无效 / 缺失令牌 |
| `update-unauthorized` | 更新检查 / 下载接口无效 / 缺失令牌 |
| `register-throttled` | 设备注册触发限流（每 IP 每小时 >10 次） |

每条记录含 `ts`（ISO 时间）与 `ip`（优先 Cloudflare `CF-Connecting-IP`）。日志只记录安全相关事件，不含转换内容与个人数据。

## Docker 部署

构建镜像：

```bash
docker build -t lj-converter .
```

运行（建议设置 Token）：

```bash
docker run -d --name lj-converter \
  -p 31876:31876 \
  -e CONVERSION_TOKEN='你的强随机Token' \
  -e ADMIN_TOKEN='另一个强随机Token' \
  -v lj-data:/data \
  lj-converter
```

## 自购域名 + Cloudflare Tunnel 部署（Windows 家用电脑）

指挥端跑在自有 Windows 电脑上，通过 Cloudflare Tunnel 把本机 31876 端口暴露为 HTTPS 域名，手机与网页管理都走域名访问，无需公网 IP / 端口映射。

1. 安装 Docker Desktop for Windows，并启动内置 WSL2 引擎。
2. 生成两个强 Token（Windows 可用 PowerShell：`openssl rand -hex 24`）。
3. 构建镜像并运行：

   ```bash
   docker build -t lj-converter .
   docker run -d --name lj-converter --restart unless-stopped \
     -p 127.0.0.1:31876:31876 \
     -e CONVERSION_TOKEN='你的强随机Token' \
     -e ADMIN_TOKEN='另一个强随机Token' \
     -v lj-data:/data \
     lj-converter
   ```

   注意只绑定到 `127.0.0.1`，公网仅由 Cloudflare Tunnel 出口。
4. 安装 cloudflared 并登录：`cloudflared tunnel login`。
5. 创建隧道并绑定域名（先把域名解析托管到 Cloudflare）：
   `cloudflared tunnel create lj` → `cloudflared tunnel route dns lj lj.你的域名.com`。
6. 编辑隧道配置文件，把 `lj.你的域名.com` 转发到 `http://127.0.0.1:31876`，然后
   `cloudflared service install` 设为开机自启服务。
7. （推荐）在 Cloudflare Zero Trust 里给该域名加 Access 应用并选“邮箱登录”，作为管理页的额外一层访问控制。具体步骤：

   - 打开 [Cloudflare Zero Trust](https://one.dash.cloudflare.com/) → 左侧 **Access → Applications → Add an application**。
   - 类型选 **Self-hosted**。Application domain 填 `lj.你的域名.com`，Session duration 选 1 day 或 1 week。
   - Policy 名称随意；Action 选 **Allow**；Include 选 **Emails**，邮箱填 `YOUR_QQ_EMAIL`（你自己的授权邮箱）。
   - 保存后点 **Authentication → Login methods**，确认邮箱（Email OTP）登录方式已启用。
   - 效果：任何人访问 `https://lj.你的域名.com`（含 `/admin`）都会先被 Cloudflare 拦下要求邮箱验证码，只有该邮箱能通过，之后才到服务自身的 ADMIN_TOKEN 登录。
8. 手机端：新 App 已内置服务端公网域名（改 `app.js` 的 `DEFAULT_CONVERSION_URL` 后重新打包），打开即自动连接；用户用自己邮箱验证码登录后自动绑定，无需向手机下发 Token。

## 云服务器部署备选

1. 在云服务器（阿里云/腾讯云轻量 1C2G 即可）安装 Docker 后运行上述命令。
2. 配置 HTTPS 域名：用 Nginx/Caddy 反向代理到 31876 端口，并申请免费证书。
3. 安全组放行 443（HTTPS），不要公网直接暴露 31876。
4. 生成强 Token：`openssl rand -hex 24`，填到 CONVERSION_TOKEN（兜底只读）与 ADMIN_TOKEN（管理端）。
5. 手机端：把 `app.js` 的 `DEFAULT_CONVERSION_URL` 改为你的 HTTPS 域名后重新打包；用户打开 App 即自动连接，用邮箱验证码登录即可开始同步。

## 备份数据说明

`PUT /v1/backup` 收到的 JSON 按归属目录存放：
- 账号令牌 → `$BACKUP_DIR/acct-<sha256(email)前16位>/backup-<id>.json`
- 遗留设备令牌 → 若已绑定邮箱则归并进账号目录，否则设备哈希目录 `$BACKUP_DIR/<deviceTokenHash>/backup-<id>.json`

注意：备份 JSON 含日记与照片的 Base64，属隐私数据，务必启用 HTTPS 并妥善保护 Token。
