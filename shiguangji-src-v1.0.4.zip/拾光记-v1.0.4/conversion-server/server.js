'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { execFile, spawn } = require('child_process');
const { pathToFileURL } = require('url');

function loadEnvFile(file) {
  try {
    const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/);
    for (const line of lines) {
      const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
      if (!m) continue;
      const k = m[1];
      const v = m[2].replace(/^['"]|['"]$/g, '');
      if (process.env[k] === undefined || process.env[k] === '') process.env[k] = v;
    }
  } catch (_) { /* ignore missing file */ }
}

loadEnvFile(path.join(__dirname, 'server.env'));

const PORT = Number(process.env.PORT || 31876);
const TOKEN = process.env.CONVERSION_TOKEN || '';
const WORK_DIR_RAW = process.env.WORK_DIR || path.join(os.tmpdir(), 'lj-converter');
const WORK_DIR = path.isAbsolute(WORK_DIR_RAW) ? WORK_DIR_RAW : path.join(__dirname, WORK_DIR_RAW);
const MAX_UPLOAD_BYTES = Number(process.env.MAX_UPLOAD_MB || 200) * 1024 * 1024;
const JOBS_TTL_MS = Number(process.env.JOBS_TTL_MIN || 60) * 60 * 1000;
const BACKUP_DIR = process.env.BACKUP_DIR || path.join(WORK_DIR, 'backups');
const BACKUP_KEEP_COUNT = Math.max(1, Number(process.env.BACKUP_KEEP_COUNT || 3));
const DEVICES_FILE = process.env.DEVICES_FILE || path.join(WORK_DIR, 'devices.json');
const RELEASES_DIR = process.env.RELEASES_DIR || path.join(WORK_DIR, 'releases');
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';
const ADMIN_PAGE = process.env.ADMIN_PAGE || path.join(__dirname, 'admin.html');
const BINDINGS_FILE = process.env.BINDINGS_FILE || path.join(WORK_DIR, 'email-bindings.json');
const ACCOUNTS_FILE = process.env.ACCOUNTS_FILE || path.join(WORK_DIR, 'accounts.json');

const SMTP_HOST = process.env.SMTP_HOST || '';
const SMTP_PORT = Number(process.env.SMTP_PORT || 465);
const SMTP_MODE = process.env.SMTP_MODE || (SMTP_PORT === 587 ? 'starttls' : 'ssl');
const SMTP_USER = process.env.SMTP_USER || '';
const SMTP_PASS = process.env.SMTP_PASS || '';
const SMTP_FROM = process.env.SMTP_FROM || SMTP_USER;
const SMTP_ALLOW_INSECURE = process.env.SMTP_ALLOW_INSECURE === '1';
const smtpConfigured = () => Boolean(SMTP_HOST);

fs.mkdirSync(path.join(WORK_DIR, 'jobs'), { recursive: true });
fs.mkdirSync(path.join(WORK_DIR, 'incoming'), { recursive: true });
fs.mkdirSync(BACKUP_DIR, { recursive: true });
fs.mkdirSync(RELEASES_DIR, { recursive: true });

const { handleManagement, safeEqual, appendAudit } = require('./management');
const { sendMail } = require('./mail');

function loadDevices() {
  try {
    return JSON.parse(fs.readFileSync(DEVICES_FILE, 'utf8'));
  } catch (_) {
    return {};
  }
}

let devices = loadDevices();

function saveDevices() {
  try {
    fs.writeFileSync(DEVICES_FILE, JSON.stringify(devices, null, 2));
  } catch (err) {
    console.error('[拾光记转换服务] 设备表保存失败:', err.message);
  }
}

function newToken() {
  return 'LJ-' + crypto.randomBytes(24).toString('hex');
}

function normalizeDeviceId(value) {
  return String(value || '').trim().slice(0, 128);
}

function loadBindings() {
  try {
    return JSON.parse(fs.readFileSync(BINDINGS_FILE, 'utf8'));
  } catch (_) {
    return {};
  }
}

let bindings = loadBindings();

function saveBindings() {
  try {
    fs.writeFileSync(BINDINGS_FILE, JSON.stringify(bindings, null, 2));
  } catch (err) {
    console.error('[拾光记转换服务] 邮箱绑定表保存失败:', err.message);
  }
}

// 邮箱账号表：{ "<email小写>": { email, token, createdAt, lastSeenAt } }
// 邮箱验证码登录后签发稳定账号 token，云端数据按邮箱账号目录归属，与设备无关。
function loadAccounts() {
  try {
    return JSON.parse(fs.readFileSync(ACCOUNTS_FILE, 'utf8'));
  } catch (_) {
    return {};
  }
}

let accounts = loadAccounts();

function saveAccounts() {
  try {
    fs.writeFileSync(ACCOUNTS_FILE, JSON.stringify(accounts, null, 2));
  } catch (err) {
    console.error('[拾光记转换服务] 账号表保存失败:', err.message);
  }
}

function ensureAccount(email) {
  const key = normalizeEmail(email);
  let account = accounts[key];
  if (account) {
    account.lastSeenAt = now();
  } else {
    account = { email: key, token: newToken(), createdAt: now(), lastSeenAt: now() };
    accounts[key] = account;
    appendAudit(WORK_DIR, { type: 'account-created', emailHash: emailHash(key) });
  }
  saveAccounts();
  return account;
}

const emailCodeStore = new Map();
const EMAIL_CODE_TTL_MS = 10 * 60 * 1000;
const EMAIL_CODE_COOLDOWN_MS = 60 * 1000;
const EMAIL_CODE_MAX_ATTEMPTS = 5;

function emailHash(email) {
  return crypto.createHash('sha256').update(String(email || '').toLowerCase().trim()).digest('hex').slice(0, 16);
}

function isEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || '').trim());
}

function findDeviceIdByToken(token) {
  for (const id of Object.keys(devices)) {
    if (safeEqual(devices[id].token, token)) return id;
  }
  return null;
}

function tokenDir(token) {
  return path.join(BACKUP_DIR, crypto.createHash('sha256').update(token).digest('hex').slice(0, 16));
}

function normalizeEmail(value) {
  return String(value || '').trim().toLowerCase();
}

function accountDir(email) {
  return path.join(BACKUP_DIR, 'acct-' + emailHash(email));
}

function accountByToken(token) {
  for (const email of Object.keys(accounts)) {
    const acct = accounts[email];
    if (acct && acct.token && safeEqual(acct.token, token)) return acct;
  }
  return null;
}

function findDeviceRecordByToken(token) {
  for (const id of Object.keys(devices)) {
    if (devices[id] && safeEqual(devices[id].token, token)) return { deviceId: id, record: devices[id] };
  }
  return null;
}

function emailBoundToDevice(deviceId) {
  for (const email of Object.keys(bindings)) {
    if (bindings[email] === deviceId) return email;
  }
  return null;
}

// 鉴权 token → 云端备份目录归属：
//   账号 token      → 邮箱账号目录（主模型，目录以 acct- 前缀区分）
//   master token    → 仍按 token 哈希目录（总指挥兜底）
//   遗留设备 token  → 若该设备已绑定某邮箱账号则归并到该账号目录，否则沿用原 token 目录
function resolveBackupDir(token) {
  if (!token) return null;
  if (TOKEN && safeEqual(token, TOKEN)) return tokenDir(token);
  const acct = accountByToken(token);
  if (acct) return accountDir(acct.email);
  const dev = findDeviceRecordByToken(token);
  if (dev) {
    const email = emailBoundToDevice(dev.deviceId);
    if (email && accounts[email]) return accountDir(email);
    return tokenDir(token);
  }
  return null;
}

// 目录级搬移：把 fromDir 下 backup-*.json 全部移动到 toDir，同名改写避免覆盖；失败回滚已移动文件
function moveDirectoryBackups(fromDir, toDir) {
  if (!fs.existsSync(fromDir)) return 0;
  fs.mkdirSync(toDir, { recursive: true });
  const files = fs.readdirSync(fromDir).filter(name => /^backup-[a-f0-9]+\.json$/.test(name));
  if (!files.length) return 0;
  const moved = [];
  try {
    for (const name of files) {
      const destName = fs.existsSync(path.join(toDir, name)) ? `backup-${makeId()}.json` : name;
      fs.renameSync(path.join(fromDir, name), path.join(toDir, destName));
      moved.push(name);
    }
    try {
      if (fs.readdirSync(fromDir).length === 0) fs.rmdirSync(fromDir);
    } catch (_) {}
  } catch (err) {
    for (const name of moved) {
      try {
        const src = fs.readdirSync(toDir).filter(f => /^backup-[a-f0-9]+\.json$/.test(f));
        const origin = src.find(f => f === name) || src.find(f => /^backup-[a-f0-9]+\.json$/.test(f));
        if (origin) fs.renameSync(path.join(toDir, origin), path.join(fromDir, name));
      } catch (_) {}
    }
    throw err;
  }
  return moved.length;
}

function moveBackupsBetweenDevices(fromToken, toToken) {
  return moveDirectoryBackups(tokenDir(fromToken), tokenDir(toToken));
}

function registerDevice(deviceId) {
  const id = normalizeDeviceId(deviceId);
  if (!id) return { error: '设备标识为空' };
  const existing = devices[id];
  if (existing) {
    existing.lastSeenAt = now();
    saveDevices();
    return { token: existing.token, isNewDevice: false };
  }
  const token = newToken();
  devices[id] = { deviceId: id, token, createdAt: now(), lastSeenAt: now() };
  saveDevices();
  return { token, isNewDevice: true };
}

function isValidToken(value) {
  const token = String(value || '');
  if (!token) return false;
  if (TOKEN && safeEqual(token, TOKEN)) return true;
  if (Object.values(devices).some(d => d && safeEqual(d.token, token))) return true;
  return Object.values(accounts).some(a => a && a.token && safeEqual(a.token, token));
}

const jobs = new Map();
let queue = [];
let processing = false;

function makeId() {
  return crypto.randomBytes(12).toString('hex');
}

function now() {
  return new Date().toISOString();
}

function expireJob(id) {
  const job = jobs.get(id);
  if (!job) return;
  queue = queue.filter(q => q.id !== id);
  cleanupJobFiles(job);
  jobs.delete(id);
}

function createJob() {
  const id = makeId();
  const job = {
    id,
    status: 'queued',
    progress: 0,
    stage: '等待中',
    error: null,
    fileName: '',
    outputPath: null,
    createdAt: now(),
    updatedAt: now(),
    cleanup: null,
  };
  jobs.set(id, job);
  setTimeout(() => {
    if (jobs.has(id) && jobs.get(id).status !== 'processing') expireJob(id);
  }, JOBS_TTL_MS);
  return job;
}

function setJob(job, patch) {
  Object.assign(job, patch, { updatedAt: now() });
}

function cleanupJobFiles(job) {
  try {
    if (job.cleanup) job.cleanup();
  } catch (_) {}
}

function runQueue() {
  if (processing) return;
  processing = true;
  next();
}

function next() {
  const job = queue.shift();
  if (!job) {
    processing = false;
    return;
  }
  convertJob(job)
    .catch(err => {
      setJob(job, { status: 'failed', error: err.message || String(err) });
      cleanupJobFiles(job);
    })
    .then(() => next());
}

function findSoffice() {
  const isWin = process.platform === 'win32';
  const candidates = [];
  if (process.env.SOFFICE) candidates.push(process.env.SOFFICE);
  if (isWin) {
    const pf = process.env['ProgramFiles'] || 'C:\\Program Files';
    const pf86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
    const loRoots = [pf, pf86, process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, 'Programs') : ''];
    loRoots.filter(Boolean).forEach(r => {
      candidates.push(path.join(r, 'LibreOffice', 'program', 'soffice.exe'));
    });
    candidates.push('soffice.com', 'soffice.exe', 'soffice');
  } else {
    candidates.push(
      'soffice',
      'libreoffice',
      '/usr/bin/soffice',
      '/usr/lib/libreoffice/program/soffice',
      '/opt/libreoffice/program/soffice',
    );
  }
  return candidates.find(c => {
    try {
      if (c.includes('/') || c.includes('\\')) return fs.existsSync(c);
      if (isWin) return commandExistsWin(c);
      return spawnSyncShim(c);
    } catch (_) {
      return false;
    }
  });
}

function commandExistsWin(cmd) {
  const { spawnSync } = require('child_process');
  const r = spawnSync('where', [cmd], { shell: false });
  return r.status === 0;
}

function spawnSyncShim(cmd) {
  try {
    const { spawnSync } = require('child_process');
    const r = spawnSync('sh', ['-c', `command -v ${cmd.replace(/'/g, "'\\''")}`]);
    return r.status === 0 && String(r.stdout || '').trim().length > 0;
  } catch (_) {
    return false;
  }
}

function convertJob(job) {
  const soffice = findSoffice();
  if (!soffice) {
    return Promise.reject(new Error('服务器未安装 LibreOffice，无法转换'));
  }

  const outDir = path.join(WORK_DIR, 'out', job.id);
  fs.mkdirSync(outDir, { recursive: true });
  const jobDocxPath = path.join(outDir, job.id + '.docx');
  try {
    fs.renameSync(job.docxPath, jobDocxPath);
  } catch (_) {
    try { fs.copyFileSync(job.docxPath, jobDocxPath); } catch (e) {
      return Promise.reject(e);
    }
  }
  const docxPath = jobDocxPath;

  setJob(job, { status: 'processing', progress: 5, stage: '正在启动转换引擎' });

  return new Promise((resolve, reject) => {
    const profileDir = path.join(WORK_DIR, 'profile', job.id);
    fs.mkdirSync(profileDir, { recursive: true });

    const args = [
      '--headless',
      '--norestore',
      '--nolockcheck',
      `-env:UserInstallation=${pathToFileURL(profileDir).href}`,
      '--convert-to',
      'pdf',
      '--outdir',
      outDir,
      docxPath,
    ];

    const child = spawn(soffice, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let stderr = '';
    child.stderr.on('data', d => (stderr += String(d)));

    const progressTimer = setInterval(() => {
      const p = job.progress;
      if (p < 90) setJob(job, { progress: Math.min(90, p + 5), stage: '正在转换页面排版' });
    }, 1500);

    job.cleanup = () => {
      clearInterval(progressTimer);
      try { child.kill(); } catch (_) {}
      setTimeout(() => {
        try { fs.rmSync(job.docxPath, { force: true }); } catch (_) {}
        try { fs.rmSync(profileDir, { recursive: true, force: true }); } catch (_) {}
        try { fs.rmSync(outDir, { recursive: true, force: true }); } catch (_) {}
      }, 1000);
    };

    child.on('error', err => {
      clearInterval(progressTimer);
      reject(err);
    });

    child.on('close', code => {
      clearInterval(progressTimer);
      if (code !== 0) {
        const msg = stderr.trim().slice(-500);
        reject(new Error(msg || `LibreOffice 退出码 ${code}`));
        return;
      }
      const pdfName = fs.readdirSync(outDir).find(f => /\.pdf$/i.test(f));
      if (!pdfName) {
        reject(new Error('转换完成但未找到 PDF 输出'));
        return;
      }
      job.outputPath = path.join(outDir, pdfName);
      setJob(job, { status: 'completed', progress: 100, stage: '转换完成' });
      resolve();
    });
  });
}

function requireAuth(req) {
  const header = req.headers['authorization'] || '';
  if (!/^Bearer\s+/.test(header)) return false;
  return isValidToken(header.slice(7).trim());
}

// 判断单条记录是否含真实内容（与 App 端 entryHasContent 语义一致）
function backupEntryHasContent(e) {
  if (!e) return false;
  if (e.type === 'diary') {
    return !!(e.title || e.body || e.joy || e.plan || e.location || e.weather || e.weatherCode != null || e.temperature != null);
  }
  if (e.type === 'business') {
    return !!((e.who && e.who !== '我') || e.place || e.action || e.note || (e.expenses && e.expenses.length));
  }
  return !!((e.destination) || e.companions || e.theme || e.notes || (e.expenses && e.expenses.length) || (e.photoMeta && Object.keys(e.photoMeta).length) || e.coverAttachmentId);
}

// 备份快照是否包含任何有效内容（附件 / 草稿 / 有内容的记录 / 非默认设置）
function snapshotHasContent(backup) {
  if (!backup || typeof backup !== 'object') return false;
  if (Array.isArray(backup.attachments) && backup.attachments.length) return true;
  if (Array.isArray(backup.exportAttachments) && backup.exportAttachments.length) return true;
  if (Array.isArray(backup.exportDrafts)) {
    for (const d of backup.exportDrafts) if (d && d.name) return true;
  }
  if (Array.isArray(backup.settings)) {
    for (const x of backup.settings) if (x && x.key !== 'downloadFolder' && x.key !== 'current') return true;
  }
  if (Array.isArray(backup.entries)) {
    for (const e of backup.entries) if (backupEntryHasContent(e)) return true;
  }
  return false;
}

// 每个归属目录只保留最近 BACKUP_KEEP_COUNT 份全量快照，删除更早的备份文件以控制磁盘占用。
// 每份快照均为全量数据，保留最近数份即可支撑“找回”，无需无限累积。
function pruneOldBackups(ownerDir, keep) {
  const limit = Number.isInteger(keep) && keep > 0 ? keep : BACKUP_KEEP_COUNT;
  try {
    if (!fs.existsSync(ownerDir)) return;
    const files = fs.readdirSync(ownerDir)
      .filter(name => /^backup-[a-f0-9]+\.json$/.test(name))
      .map(name => ({ name, mtime: fs.statSync(path.join(ownerDir, name)).mtimeMs }))
      .sort((a, b) => b.mtime - a.mtime);
    for (const file of files.slice(limit)) {
      fs.unlinkSync(path.join(ownerDir, file.name));
    }
  } catch (err) {
    console.error('[拾光记转换服务] 备份快照清理失败:', err.message);
  }
}

// 返回设备目录下最新一个备份文件的完整路径；无则返回 null
function latestBackupFile(deviceDir) {
  try {
    if (!fs.existsSync(deviceDir)) return null;
    const files = fs.readdirSync(deviceDir)
      .filter(name => /^backup-[a-f0-9]+\.json$/.test(name))
      .map(name => ({ name, mtime: fs.statSync(path.join(deviceDir, name)).mtimeMs }))
      .sort((a, b) => b.mtime - a.mtime);
    return files.length ? path.join(deviceDir, files[0].name) : null;
  } catch (_) {
    return null;
  }
}

function bearerToken(req) {
  const header = req.headers['authorization'] || '';
  return /^Bearer\s+/.test(header) ? header.slice(7).trim() : '';
}

function clientIp(req) {
  const cf = req.headers['cf-connecting-ip'];
  if (cf) return String(cf).split(',')[0].trim();
  return (req.socket && req.socket.remoteAddress) || 'unknown';
}

const REGISTER_MAX_PER_IP = 10;
const REGISTER_WINDOW_MS = 60 * 60 * 1000;
const registerAttempts = new Map();

function allowRegister(ip) {
  const now = Date.now();
  const rec = registerAttempts.get(ip) || { count: 0, windowStart: now };
  if (now - rec.windowStart > REGISTER_WINDOW_MS) {
    rec.count = 0;
    rec.windowStart = now;
  }
  if (rec.count >= REGISTER_MAX_PER_IP) {
    registerAttempts.set(ip, rec);
    return false;
  }
  rec.count += 1;
  registerAttempts.set(ip, rec);
  return true;
}

function bodyToFile(req, maxBytes) {
  return new Promise((resolve, reject) => {
    const filePath = path.join(WORK_DIR, 'incoming', makeId() + '.bin');
    const ws = fs.createWriteStream(filePath);
    let size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > maxBytes) {
        req.destroy();
        reject(new Error('文件过大'));
        return;
      }
      if (!ws.write(chunk)) req.pause();
    });
    ws.on('drain', () => req.resume());
    req.on('end', () => ws.end());
    ws.on('finish', () => resolve({ filePath, size }));
    req.on('error', err => {
      ws.destroy();
      try { fs.rmSync(filePath, { force: true }); } catch (_) {}
      reject(err);
    });
    ws.on('error', err => {
      try { fs.rmSync(filePath, { force: true }); } catch (_) {}
      reject(err);
    });
  });
}

function json(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-File-Name',
  });
  res.end(body);
}

function text(res, code, text) {
  res.writeHead(code, {
    'Content-Type': 'text/plain; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-File-Name',
  });
  res.end(text);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');

  // 总指挥管理 / 更新接口优先处理
  try {
    const handled = handleManagement({
      workDir: WORK_DIR,
      devicesFile: DEVICES_FILE,
      bindingsFile: BINDINGS_FILE,
      accountsFile: ACCOUNTS_FILE,
      backupDir: BACKUP_DIR,
      releasesDir: RELEASES_DIR,
      adminToken: ADMIN_TOKEN,
      maxUploadBytes: MAX_UPLOAD_BYTES,
      adminPagePath: ADMIN_PAGE,
    }, req, res, url);
    if (handled) return;
  } catch (err) {
    console.error('[拾光记管理] 处理异常:', err);
    res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ error: '管理模块异常：' + err.message }));
    return;
  }

  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-File-Name',
    });
    res.end();
    return;
  }

  // 发送邮箱验证码（免鉴权）
  if (req.method === 'POST' && url.pathname === '/v1/auth/send-code') {
    try {
      if (!smtpConfigured()) {
        json(res, 503, { error: '服务端未配置 SMTP，无法发送验证码' });
        return;
      }
      const { filePath } = await bodyToFile(req, 16 * 1024);
      const raw = fs.readFileSync(filePath, 'utf8');
      try { fs.rmSync(filePath, { force: true }); } catch (_) {}
      const payload = JSON.parse(raw);
      const email = String(payload.email || '').toLowerCase().trim();
      if (!isEmail(email)) {
        json(res, 400, { error: '邮箱格式不正确' });
        return;
      }
      const now = Date.now();
      const prev = emailCodeStore.get(email);
      if (prev && now - prev.sentAt < EMAIL_CODE_COOLDOWN_MS) {
        json(res, 429, { error: '验证码发送过于频繁，请稍后再试', retryAfter: 60 });
        return;
      }
      const code = String(crypto.randomInt(100000, 1000000));
      emailCodeStore.set(email, { code, expiresAt: now + EMAIL_CODE_TTL_MS, attempts: 0, sentAt: now });
      const mailOpts = {
        host: SMTP_HOST,
        port: SMTP_PORT,
        mode: SMTP_MODE,
        user: SMTP_USER,
        pass: SMTP_PASS,
        from: SMTP_FROM || SMTP_USER,
        to: email,
        subject: '拾光记 邮箱验证码',
        text: `你的拾光记验证码是：${code}\n\n10 分钟内有效。若非本人操作，请忽略本邮件。`,
        allowInsecure: SMTP_ALLOW_INSECURE,
      };
      try {
        await sendMail(mailOpts);
        appendAudit(WORK_DIR, { type: 'auth-code-sent', emailHash: emailHash(email), ip: clientIp(req) });
        json(res, 200, { ok: true, retryAfter: 60 });
      } catch (err) {
        emailCodeStore.delete(email);
        appendAudit(WORK_DIR, { type: 'auth-code-send-fail', emailHash: emailHash(email), ip: clientIp(req), reason: err.message });
        json(res, 500, { error: '验证码邮件发送失败：' + err.message });
      }
    } catch (err) {
      json(res, 400, { error: '请求无效：' + err.message });
    }
    return;
  }

  // 邮箱验证码登录（首绑或换机接管，免鉴权）
  if (req.method === 'POST' && url.pathname === '/v1/auth/login') {
    try {
      if (!smtpConfigured()) {
        json(res, 503, { error: '服务端未配置 SMTP，无法登录' });
        return;
      }
      const { filePath } = await bodyToFile(req, 16 * 1024);
      const raw = fs.readFileSync(filePath, 'utf8');
      try { fs.rmSync(filePath, { force: true }); } catch (_) {}
      const payload = JSON.parse(raw);
      const email = String(payload.email || '').toLowerCase().trim();
      const code = String(payload.code || '').trim();
      const deviceId = normalizeDeviceId(payload.deviceId);
      if (!isEmail(email)) {
        json(res, 400, { error: '邮箱格式不正确' });
        return;
      }
      const rec = emailCodeStore.get(email);
      if (!rec) {
        json(res, 400, { error: '请先获取验证码' });
        return;
      }
      if (Date.now() > rec.expiresAt) {
        emailCodeStore.delete(email);
        json(res, 400, { error: '验证码已过期，请重新获取' });
        return;
      }
      if (!safeEqual(rec.code, code)) {
        rec.attempts += 1;
        appendAudit(WORK_DIR, { type: 'auth-code-fail', emailHash: emailHash(email), ip: clientIp(req) });
        if (rec.attempts >= EMAIL_CODE_MAX_ATTEMPTS) {
          emailCodeStore.delete(email);
          json(res, 429, { error: '验证码错误次数过多，请重新获取' });
        } else {
          json(res, 400, { error: `验证码错误，还剩 ${EMAIL_CODE_MAX_ATTEMPTS - rec.attempts} 次机会` });
        }
        return;
      }
      emailCodeStore.delete(email);
      const emailKey = normalizeEmail(email);
      const isNewAccount = !accounts[emailKey];
      const account = ensureAccount(email);
      let action = isNewAccount ? 'bound' : 'login';
      let movedBackups = 0;
      // 一次性 legacy 迁移：该邮箱历史上绑定的旧设备目录归并到邮箱账号目录，成功后清理旧绑定并作废旧设备
      const boundDeviceId = bindings[email] || null;
      if (boundDeviceId && boundDeviceId !== deviceId) {
        const source = devices[boundDeviceId];
        if (source) {
          movedBackups = moveDirectoryBackups(tokenDir(source.token), accountDir(email));
          delete devices[boundDeviceId];
          saveDevices();
          action = 'migrated';
          appendAudit(WORK_DIR, {
            type: 'device-migrate-ok',
            ip: clientIp(req),
            emailHash: emailHash(email),
            fromDeviceId: boundDeviceId,
            toAccountDir: path.basename(accountDir(email)),
            movedBackups,
          });
        }
        delete bindings[email];
        saveBindings();
      }
      // 兼容旧版 App：登录附带 deviceId 时登记其为该邮箱的活跃设备，使其后续备份归并到同一账号目录
      if (deviceId) {
        const register = registerDevice(deviceId);
        if (!register.error) {
          bindings[email] = deviceId;
          saveBindings();
          if (action === 'login') action = 'bound';
        }
      }
      appendAudit(WORK_DIR, { type: 'auth-login-ok', emailHash: emailHash(email), action, deviceId: deviceId || null, ip: clientIp(req) });
      json(res, 200, { ok: true, action, token: account.token, movedBackups });
    } catch (err) {
      json(res, 400, { error: '登录请求无效：' + err.message });
    }
    return;
  }

  // 设备绑定注册（免鉴权，首次绑定用）
  if (req.method === 'POST' && url.pathname === '/v1/device/register') {
    try {
      const ip = clientIp(req);
      if (!allowRegister(ip)) {
        appendAudit(WORK_DIR, { type: 'register-throttled', ip });
        json(res, 429, { error: '注册过于频繁，请稍后再试' });
        return;
      }
      const { filePath } = await bodyToFile(req, 16 * 1024);
      const raw = fs.readFileSync(filePath, 'utf8');
      try { fs.rmSync(filePath, { force: true }); } catch (_) {}
      const payload = JSON.parse(raw);
      const result = registerDevice(payload.deviceId);
      if (result.error) {
        json(res, 400, { error: result.error });
        return;
      }
      json(res, 200, { token: result.token, isNewDevice: result.isNewDevice });
    } catch (err) {
      json(res, 400, { error: '设备注册请求无效：' + err.message });
    }
    return;
  }

  if (!requireAuth(req)) {
    json(res, 401, { error: '未授权的请求' });
    return;
  }

  // 健康检查 / 备份连接检查
  if (req.method === 'GET' && url.pathname === '/v1/backup/status') {
    json(res, 200, { ok: true, time: now() });
    return;
  }

  // 备份数据存储（按账号目录/设备目录归属隔离）
  if (req.method === 'PUT' && url.pathname === '/v1/backup') {
    try {
      const ownerDir = resolveBackupDir(bearerToken(req));
      if (!ownerDir) {
        json(res, 401, { error: '未授权的请求' });
        return;
      }
      const { filePath, size } = await bodyToFile(req, MAX_UPLOAD_BYTES);
      // 空快照保护：若新快照无任何有效内容，且该归属已有含内容的备份，
      // 则拒绝将其置为最新（卸载重装后空库/未恢复完成的自动同步可能误伤云端数据）。
      if (size < 1 * 1024 * 1024) {
        const incoming = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        const allowed = incoming && incoming.backupMeta && incoming.backupMeta.allowEmpty === true;
        if (!allowed && !snapshotHasContent(incoming)) {
          const existing = latestBackupFile(ownerDir);
          if (existing) {
            const previous = JSON.parse(fs.readFileSync(existing, 'utf8'));
            if (snapshotHasContent(previous)) {
              fs.unlinkSync(filePath);
              json(res, 200, { ok: true, backupId: null, skipped: 'empty-snapshot', savedAt: now() });
              return;
            }
          }
        }
      }
      fs.mkdirSync(ownerDir, { recursive: true });
      const backupId = makeId();
      const dest = path.join(ownerDir, `backup-${backupId}.json`);
      fs.renameSync(filePath, dest);
      pruneOldBackups(ownerDir);
      json(res, 200, { ok: true, backupId, savedAt: now() });
    } catch (err) {
      json(res, 500, { error: '备份保存失败：' + err.message });
    }
    return;
  }

  // 拉取当前账号/设备最新备份（卸载重装后恢复用）
  if (req.method === 'GET' && url.pathname === '/v1/backup/latest') {
    const ownerDir = resolveBackupDir(bearerToken(req));
    if (!ownerDir) {
      json(res, 401, { error: '未授权的请求' });
      return;
    }
    try {
      if (!fs.existsSync(ownerDir)) {
        json(res, 200, { ok: true, backup: null });
        return;
      }
      const files = fs.readdirSync(ownerDir)
        .filter(name => /^backup-[a-f0-9]+\.json$/.test(name))
        .map(name => ({ name, mtime: fs.statSync(path.join(ownerDir, name)).mtimeMs }))
        .sort((a, b) => b.mtime - a.mtime);
      if (!files.length) {
        json(res, 200, { ok: true, backup: null });
        return;
      }
      const backup = JSON.parse(fs.readFileSync(path.join(ownerDir, files[0].name), 'utf8'));
      json(res, 200, { ok: true, backup });
    } catch (err) {
      json(res, 500, { error: '读取备份失败：' + err.message });
    }
    return;
  }

  // 创建转换任务
  if (req.method === 'POST' && url.pathname === '/v1/jobs') {
    const fileName = String(req.headers['x-file-name'] || '文档.docx').replace(/[\\/:*?"<>|]/g, '').trim() || '文档.docx';
    try {
      const { filePath } = await bodyToFile(req, MAX_UPLOAD_BYTES);
      const job = createJob();
      job.fileName = fileName;
      job.docxPath = filePath;
      setJob(job, { stage: '已接收，等待转换' });
      queue.push(job);
      runQueue();
      json(res, 202, { jobId: job.id });
    } catch (err) {
      json(res, 400, { error: '接收文件失败：' + err.message });
    }
    return;
  }

  // 任务状态 / 结果 / 取消
  const jobMatch = url.pathname.match(/^\/v1\/jobs\/([a-f0-9]+)$/);
  const resultMatch = url.pathname.match(/^\/v1\/jobs\/([a-f0-9]+)\/result$/);

  if (req.method === 'GET' && jobMatch) {
    const job = jobs.get(jobMatch[1]);
    if (!job) {
      json(res, 404, { status: 'failed', error: '任务不存在或已过期', progress: 0, stage: '任务不存在' });
      return;
    }
    json(res, 200, {
      jobId: job.id,
      status: job.status,
      progress: job.progress,
      stage: job.stage,
      error: job.error,
    });
    return;
  }

  if (req.method === 'GET' && resultMatch) {
    const job = jobs.get(resultMatch[1]);
    if (!job || !job.outputPath || !fs.existsSync(job.outputPath)) {
      json(res, 404, { error: '结果不存在或已过期' });
      return;
    }
    const downloadName = job.fileName.replace(/\.docx$/i, '') + '.pdf';
    res.writeHead(200, {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(downloadName)}`,
      'Access-Control-Allow-Origin': '*',
      'Content-Length': fs.statSync(job.outputPath).size,
    });
    fs.createReadStream(job.outputPath).pipe(res);
    return;
  }

  if (req.method === 'DELETE' && jobMatch) {
    const job = jobs.get(jobMatch[1]);
    if (job) {
      cleanupJobFiles(job);
      jobs.delete(jobMatch[1]);
    }
    text(res, 204, '');
    return;
  }

  json(res, 404, { error: '接口不存在' });
});

server.listen(PORT, () => {
  console.log(`[拾光记转换服务] 监听端口 ${PORT}`);
  console.log(`[拾光记转换服务] 工作目录 ${WORK_DIR}`);
  if (!TOKEN) console.log('[拾光记转换服务] 警告: 未设置 CONVERSION_TOKEN，设备注册后凭设备令牌访问');
  if (!ADMIN_TOKEN) console.log('[拾光记转换服务] 警告: 未设置 ADMIN_TOKEN，管理接口不可用');
  if (!smtpConfigured()) console.log('[拾光记转换服务] 警告: 未设置 SMTP_HOST/SMTP_USER/SMTP_PASS，邮箱登录不可用');
  const soffice = findSoffice();
  if (soffice) {
    console.log(`[拾光记转换服务] LibreOffice: ${soffice}`);
  } else {
    console.log(`[拾光记转换服务] 警告: 未找到 LibreOffice，转换将失败`);
  }
});
