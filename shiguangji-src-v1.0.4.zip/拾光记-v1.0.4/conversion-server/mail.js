'use strict';

const net = require('net');
const tls = require('tls');

function encodeHeader(value) {
  return '=?UTF-8?B?' + Buffer.from(String(value), 'utf8').toString('base64') + '?=';
}

function wrapBase64(str) {
  const b64 = Buffer.from(str, 'utf8').toString('base64');
  const out = [];
  for (let i = 0; i < b64.length; i += 76) out.push(b64.slice(i, i + 76));
  return out.join('\r\n');
}

function buildMessage(o) {
  const parts = [];
  parts.push('From: ' + o.from);
  parts.push('To: ' + o.to);
  parts.push('Subject: ' + encodeHeader(o.subject));
  parts.push('MIME-Version: 1.0');
  parts.push('Content-Type: text/plain; charset=utf-8');
  parts.push('Content-Transfer-Encoding: base64');
  parts.push('');
  parts.push(wrapBase64(o.text || ''));
  return parts.join('\r\n');
}

function createIo(socket, timeoutMs) {
  let buf = '';
  let expectCode = null;
  let resolver = null;
  let rejecter = null;
  const fail = err => {
    if (rejecter) {
      const r = rejecter;
      rejecter = null;
      resolver = null;
      r(err);
    }
  };
  socket.on('data', chunk => {
    buf += chunk.toString('utf8');
    for (;;) {
      const nl = buf.indexOf('\r\n');
      if (nl < 0) break;
      const line = buf.slice(0, nl);
      buf = buf.slice(nl + 2);
      const m = /^(\d{3})([ -])(.*)$/.exec(line);
      if (!m) continue;
      const code = Number(m[1]);
      if (m[2] === ' ' && resolver) {
        const r = resolver;
        const expected = expectCode;
        resolver = null;
        rejecter = null;
        if (code === expected) r(code);
        else r(new Error('SMTP 期望 ' + expected + ' 收到 ' + code + ' ' + m[3]));
      }
    }
  });
  socket.on('error', fail);
  socket.setTimeout(timeoutMs, () => fail(new Error('SMTP 连接超时')));
  return {
    send(line) {
      socket.write(String(line) + '\r\n');
    },
    expect(code) {
      expectCode = code;
      return new Promise((res, rej) => {
        resolver = res;
        rejecter = rej;
      });
    },
    writeRaw(data) {
      socket.write(data);
    },
    destroy() {
      socket.destroy();
    },
  };
}

function waitEvent(emitter, event) {
  return new Promise((resolve, reject) => {
    const onErr = err => {
      cleanup();
      reject(err);
    };
    const onOk = () => {
      cleanup();
      resolve();
    };
    const cleanup = () => {
      emitter.removeListener(event, onOk);
      emitter.removeListener('error', onErr);
    };
    emitter.once(event, onOk);
    emitter.once('error', onErr);
  });
}

/**
 * 发送单封文本邮件（零依赖 SMTP 客户端）。
 * opts: { host, port, mode, user, pass, from, to, subject, text, allowInsecure }
 * mode: 'ssl' | 'starttls' | 'plain'
 */
async function sendMail(opts) {
  const host = opts.host;
  const port = Number(opts.port || 465);
  const mode = opts.mode || (port === 587 ? 'starttls' : 'ssl');
  const timeoutMs = Number(opts.timeoutMs || 15000);
  const rejectUnauthorized = opts.allowInsecure !== true;

  let socket;
  if (mode === 'ssl') {
    socket = tls.connect({ host, port, servername: host, rejectUnauthorized });
    await waitEvent(socket, 'secureConnect');
  } else {
    socket = net.connect({ host, port });
    await waitEvent(socket, 'connect');
  }

  let io = createIo(socket, timeoutMs);
  try {
    await io.expect(220);
    io.send('EHLO ' + host);
    await io.expect(250);

    if (mode === 'starttls') {
      io.send('STARTTLS');
      await io.expect(220);
      const upgraded = tls.connect({ socket, servername: host, rejectUnauthorized });
      await waitEvent(upgraded, 'secureConnect');
      io.destroy();
      io = createIo(upgraded, timeoutMs);
      socket = upgraded;
      io.send('EHLO ' + host);
      await io.expect(250);
    }

    if (opts.user && opts.pass) {
      io.send('AUTH LOGIN');
      await io.expect(334);
      io.send(Buffer.from(opts.user, 'utf8').toString('base64'));
      await io.expect(334);
      io.send(Buffer.from(opts.pass, 'utf8').toString('base64'));
      await io.expect(235);
    }

    io.send('MAIL FROM:<' + opts.from + '>');
    await io.expect(250);
    io.send('RCPT TO:<' + opts.to + '>');
    await io.expect(250);
    io.send('DATA');
    await io.expect(354);
    io.writeRaw(buildMessage(opts) + '\r\n.\r\n');
    await io.expect(250);
    io.send('QUIT');
    try { socket.end(); } catch (_) {}
    return true;
  } finally {
    try { socket.destroy(); } catch (_) {}
  }
}

module.exports = { sendMail };
