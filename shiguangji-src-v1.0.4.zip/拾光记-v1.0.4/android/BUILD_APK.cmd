@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title LifeJourney APK Builder

set "ANDROID_HOME=C:\Users\86198\AppData\Local\Android\Sdk"
set "ANDROID_SDK_ROOT=C:\Users\86198\AppData\Local\Android\Sdk"
set "LOG=%~dp0build-apk.log"
set "APK=%~dp0app\build\outputs\apk\debug\app-debug.apk"

cls
echo ========================================
echo       LifeJourney Android APK Builder
echo ========================================
echo.
echo Build started.>"%LOG%"
echo Android SDK: %ANDROID_HOME%>>"%LOG%"
echo Project: %CD%>>"%LOG%"
echo.

if not exist "%ANDROID_HOME%\platforms\android-36\android.jar" goto sdk_error
if not exist "%ANDROID_HOME%\build-tools\36.0.0\aapt2.exe" goto sdk_error
if not exist "%~dp0gradlew.bat" goto wrapper_error
if not exist "%~dp0gradle\wrapper\gradle-wrapper.jar" goto wrapper_error

echo [1/3] Android SDK and Gradle Wrapper are ready.
echo [2/3] Building APK. Output is being saved to build-apk.log...
echo       Keep this window open.
call "%~dp0gradlew.bat" :app:assembleDebug --console=plain --no-daemon >>"%LOG%" 2>&1
set "BUILD_RESULT=%ERRORLEVEL%"

if not "%BUILD_RESULT%"=="0" goto build_error
if not exist "%APK%" goto apk_error

echo [3/3] BUILD SUCCESSFUL
echo.
echo APK: %APK%
for %%F in ("%APK%") do echo Size: %%~zF bytes
echo.
explorer.exe /select,"%APK%"
goto end

:sdk_error
echo ERROR: Android SDK 36 or Build Tools 36.0.0 is missing.
echo ERROR: Android SDK 36 or Build Tools 36.0.0 is missing.>>"%LOG%"
goto fail

:wrapper_error
echo ERROR: Gradle Wrapper is missing.
echo ERROR: Gradle Wrapper is missing.>>"%LOG%"
goto fail

:build_error
echo.
echo ERROR: Gradle build failed with exit code %BUILD_RESULT%.
echo See: %LOG%
goto fail

:apk_error
echo ERROR: Build ended but the APK file was not found.
echo ERROR: APK output missing.>>"%LOG%"
goto fail

:fail
echo.
echo BUILD DID NOT COMPLETE.
echo Send build-apk.log for diagnosis.

:end
echo.
echo Press any key to close...
pause >nul
endlocal
