@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title LifeJourney APK Builder

set "LOG=%~dp0build-apk.log"
set "APK=%~dp0app\build\outputs\apk\debug\app-debug.apk"
set "WRAPPER=%~dp0gradle\wrapper\gradle-wrapper.jar"
set "WRAPPER_SOURCE=C:\Users\86198\MyApplication\gradle\wrapper\gradle-wrapper.jar"

cls
echo ========================================
echo       LifeJourney Android APK Builder
echo ========================================
echo Project: %CD%
echo Log:     %LOG%
echo.
echo [%date% %time%] Build started. > "%LOG%"

where java >nul 2>&1
if errorlevel 1 goto no_java

echo [1/4] Preparing Android SDK and Gradle Wrapper...
if not exist "%~dp0local.properties" (
  echo sdk.dir=C\:\\Users\\86198\\AppData\\Local\\Android\\Sdk>"%~dp0local.properties"
)
if not exist "C:\Users\86198\AppData\Local\Android\Sdk\platforms\android-36\android.jar" goto no_android_sdk
if not exist "%WRAPPER_SOURCE%" goto no_wrapper_source
if not exist "%~dp0gradle\wrapper" mkdir "%~dp0gradle\wrapper"
copy /y "%WRAPPER_SOURCE%" "%WRAPPER%" >nul
if errorlevel 1 goto copy_failed
echo       Wrapper is ready.

echo [2/4] Preparing Gradle 7.6...
echo       The first download is about 120 MB. Please wait.
call "%~dp0gradlew.bat" --version >> "%LOG%" 2>&1
if errorlevel 1 goto gradle_failed
echo       Gradle is ready.

echo [3/4] Compiling Debug APK. Keep this window open...
call "%~dp0gradlew.bat" :app:assembleDebug --console=plain --no-daemon >> "%LOG%" 2>&1
if errorlevel 1 goto build_failed

echo [4/4] Checking APK output...
if not exist "%APK%" goto apk_missing

echo.
echo ========================================
echo BUILD SUCCESSFUL
echo APK: %APK%
for %%F in ("%APK%") do echo Size: %%~zF bytes
echo ========================================
echo.
explorer.exe /select,"%APK%"
echo The APK folder has been opened.
goto finish

:no_java
echo ERROR: Java was not found. Install JDK 17 first.
echo ERROR: Java was not found. >> "%LOG%"
goto failed

:no_android_sdk
echo ERROR: Android SDK Platform 36 was not found.
echo ERROR: Android SDK Platform 36 was not found. >> "%LOG%"
goto failed

:no_wrapper_source
echo ERROR: Complete Gradle Wrapper JAR was not found:
echo %WRAPPER_SOURCE%
echo ERROR: Wrapper source missing. >> "%LOG%"
goto failed

:copy_failed
echo ERROR: Failed to copy gradle-wrapper.jar.
echo ERROR: Failed to copy gradle-wrapper.jar. >> "%LOG%"
goto failed

:gradle_failed
echo ERROR: Gradle Wrapper failed to start.
goto show_log

:build_failed
echo ERROR: APK compilation failed.
goto show_log

:apk_missing
echo ERROR: Gradle finished but APK was not found.
echo ERROR: APK not found at %APK% >> "%LOG%"
goto show_log

:show_log
echo.
echo ---------------- BUILD LOG ----------------
type "%LOG%"
echo -------------- END BUILD LOG --------------
goto failed

:failed
echo.
echo ========================================
echo BUILD DID NOT COMPLETE
echo Send this log file for diagnosis:
echo %LOG%
echo ========================================

:finish
echo.
echo Press any key to close this window...
pause >nul
endlocal
exit /b 0
