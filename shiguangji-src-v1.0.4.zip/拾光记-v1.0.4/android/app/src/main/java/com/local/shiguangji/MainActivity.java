package com.local.shiguangji;

import android.Manifest;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.ContentValues;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.content.FileProvider;

import org.apache.cordova.CordovaActivity;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends CordovaActivity {
    private static final int LOCATION_PERMISSION_REQUEST = 9101;
    private static final int CAMERA_PERMISSION_REQUEST = 9102;
    private static final int CAMERA_CAPTURE_REQUEST = 9103;
    private static final int DOWNLOAD_FOLDER_REQUEST = 9104;
    private static final String DOWNLOAD_PREFS = "life_journey_download";
    private static final String DOWNLOAD_FOLDER_URI = "folder_uri";
    private static final String BACKUP_NAME = "拾光记-数据备份.json";
    private static final String PRIVATE_BACKUP_DIR = "backup";
    private static final String BACKUP_PREFS = "life_journey_backup";
    private static final String BACKUP_LOCAL_SIGNATURE = "backupLocalSignature";
    private static final String SERVICE_URL_PREF = "service_url";
    private static final String CLOUD_SYNC_MTIME = "cloud_sync_mtime";
    private static final String CLOUD_SYNC_SIZE = "cloud_sync_size";

    private WebView systemWebView;
    private File pendingPhotoFile;
    private volatile HttpURLConnection conversionConnection;
    private volatile boolean conversionCancelled;
    private volatile String conversionJobId;
    private volatile String conversionServiceUrl;
    private volatile String conversionToken;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int appBackground = Color.rgb(248, 243, 233);
        setTaskDescription(new ActivityManager.TaskDescription("拾光记", null, appBackground));
        getWindow().getDecorView().setBackgroundColor(appBackground);
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.getBoolean("cdvStartInBackground", false)) {
            moveTaskToBack(true);
        }
        init();
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        getWindow().setStatusBarColor(appBackground);
        getWindow().setNavigationBarColor(appBackground);
        systemWebView = (WebView) appView.getEngine().getView();
        systemWebView.setBackgroundColor(appBackground);
        systemWebView.clearCache(true);
        systemWebView.addJavascriptInterface(new NativeAccess(), "LifeJourneyNative");
        BackupJobService.schedule(this);
        loadUrl(launchUrl);
    }

    private class NativeAccess {
        @JavascriptInterface
        public String getAndroidId() {
            return Settings.Secure.getString(MainActivity.this.getContentResolver(), Settings.Secure.ANDROID_ID);
        }

        @JavascriptInterface
        public void saveDeviceToken(String token) {
            downloadPreferences().edit().putString("device_token", token == null ? "" : token).apply();
        }

        @JavascriptInterface
        public String getDeviceToken() {
            return downloadPreferences().getString("device_token", "");
        }

        @JavascriptInterface
        public void rememberServiceUrl(String serviceUrl) {
            rememberServiceUrlPrivate(serviceUrl);
        }

        @JavascriptInterface
        public boolean hasExistingBackup() {
            try {
                byte[] bytes = readPrivateBackupBytes();
                return bytes != null && bytes.length > 0;
            } catch (Exception ignored) {
                return false;
            }
        }

        @JavascriptInterface
        public String readBackupFile() {
            try {
                byte[] bytes = readPrivateBackupBytes();
                if (bytes == null || bytes.length == 0) return "";
                return new String(bytes, StandardCharsets.UTF_8);
            } catch (Exception ignored) {
                return "";
            }
        }

        @JavascriptInterface
        public boolean hasLocationPermission() {
            return ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface
        public void requestLocationPermission() {
            runOnUiThread(() -> ActivityCompat.requestPermissions(
                    MainActivity.this,
                    new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST));
        }

        @JavascriptInterface
        public void capturePhoto() {
            runOnUiThread(() -> {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA)
                        == PackageManager.PERMISSION_GRANTED) {
                    openCamera();
                } else {
                    ActivityCompat.requestPermissions(
                            MainActivity.this,
                            new String[]{Manifest.permission.CAMERA},
                            CAMERA_PERMISSION_REQUEST);
                }
            });
        }

        @JavascriptInterface
        public void chooseDownloadFolder() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                    startActivityForResult(intent, DOWNLOAD_FOLDER_REQUEST);
                } catch (Exception error) {
                    evaluateJavascript("window.onNativeDownloadFolderChanged&&window.onNativeDownloadFolderChanged(false,'无法打开系统文件夹选择器')");
                }
            });
        }

        @JavascriptInterface
        public void clearDownloadFolder() {
            clearSavedDownloadFolder();
            evaluateJavascript("window.onNativeDownloadFolderChanged&&window.onNativeDownloadFolderChanged(true,'已恢复系统 Download 下载目录')");
        }

        @JavascriptInterface
        public String getDownloadFolderName() {
            Uri uri = getSavedDownloadFolder();
            return uri == null ? "" : getFolderName(uri);
        }

        @JavascriptInterface
        public String inflateRawBase64(String value) {
            try {
                byte[] compressed = Base64.decode(value, Base64.DEFAULT);
                Inflater inflater = new Inflater(true);
                inflater.setInput(compressed);
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                while (!inflater.finished()) {
                    int count = inflater.inflate(buffer);
                    if (count > 0) output.write(buffer, 0, count);
                    else if (inflater.needsInput() || inflater.needsDictionary()) throw new DataFormatException("DOCX 压缩条目不完整");
                }
                inflater.end();
                return Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP);
            } catch (Exception error) {
                return "";
            }
        }

        @JavascriptInterface
        public void openWordInOffice(String base64, String fileName) {
            try {
                String safeName = sanitizeFileName(fileName);
                if (!safeName.toLowerCase(Locale.ROOT).endsWith(".docx")) safeName += ".docx";
                File directory = new File(getCacheDir(), "office_documents");
                if (!directory.exists() && !directory.mkdirs()) throw new IOException("无法创建文档缓存目录");
                File file = new File(directory, safeName);
                try (FileOutputStream output = new FileOutputStream(file)) {
                    output.write(Base64.decode(base64, Base64.DEFAULT));
                }
                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file);
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(uri, "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                runOnUiThread(() -> {
                    try {
                        startActivity(Intent.createChooser(intent, "使用 Office/WPS 打开并导出 PDF"));
                    } catch (Exception error) {
                        evaluateJavascript("window.onNativeOfficeOpenFailed&&window.onNativeOfficeOpenFailed('手机未安装可打开 Word 的 Office/WPS')");
                    }
                });
            } catch (Exception error) {
                evaluateJavascript("window.onNativeOfficeOpenFailed&&window.onNativeOfficeOpenFailed(" + JSONObject.quote(error.getMessage() == null ? "无法打开 Word" : error.getMessage()) + ")");
            }
        }

        @JavascriptInterface
        public void convertWordToPdf(String serviceUrl, String token, String base64, String sourceFileName, String outputFileName) {
            if (conversionConnection != null) return;
            conversionCancelled = false;
            conversionJobId = null;
            conversionServiceUrl = serviceUrl == null ? "" : serviceUrl.replaceAll("/+$", "");
            conversionToken = token == null ? "" : token;
            new Thread(() -> runWordConversion(base64, sourceFileName, outputFileName)).start();
        }

        @JavascriptInterface
        public void cancelWordConversion() {
            conversionCancelled = true;
            HttpURLConnection connection = conversionConnection;
            if (connection != null) connection.disconnect();
            new Thread(() -> deleteConversionJob()).start();
        }

        @JavascriptInterface
        public void saveAutomaticBackup(String json, String fileName) {
            new Thread(() -> saveAutomaticBackupPrivate(json, fileName)).start();
        }

        @JavascriptInterface
        public void uploadBackup(String json, String serviceUrl, String token) {
            new Thread(() -> uploadBackupFromBridge(json, serviceUrl, token)).start();
        }

        @JavascriptInterface
        public void checkBackupConnection(String serviceUrl, String token) {
            new Thread(() -> checkBackupConnectionFromBridge(serviceUrl, token)).start();
        }

        @JavascriptInterface
        public void saveDataBackup(String json, String fileName) {
            new Thread(() -> {
                try {
                    String savedName = writeJsonToDownloads(json, fileName);
                    evaluateJavascript("window.onNativeDataBackupSaved&&window.onNativeDataBackupSaved(true," + JSONObject.quote("已导出到下载目录：" + savedName) + ")");
                } catch (Exception error) {
                    evaluateJavascript("window.onNativeDataBackupSaved&&window.onNativeDataBackupSaved(false," + JSONObject.quote(error.getMessage() == null ? "导出失败" : error.getMessage()) + ")");
                }
            }).start();
        }

        @JavascriptInterface
        public void saveDocx(String json, String fileName) {
            new Thread(() -> {
                try {
                    String savedName = writeDocxToDownloads(json, fileName);
                    evaluateJavascript("window.onNativeDocxSaved&&window.onNativeDocxSaved(true," + JSONObject.quote(savedName) + ")");
                } catch (Exception error) {
                    evaluateJavascript("window.onNativeDocxSaved&&window.onNativeDocxSaved(false," + JSONObject.quote(error.getMessage() == null ? "保存失败" : error.getMessage()) + ")");
                }
            }).start();
        }

        @JavascriptInterface
        public void savePdf(String json, String fileName) {
            new Thread(() -> {
                try {
                    String savedName = writePdfToDownloads(json, fileName);
                    evaluateJavascript("window.onNativePdfSaved&&window.onNativePdfSaved(true," + JSONObject.quote(savedName) + ")");
                } catch (Exception error) {
                    evaluateJavascript("window.onNativePdfSaved&&window.onNativePdfSaved(false," + JSONObject.quote(error.getMessage() == null ? "保存失败" : error.getMessage()) + ")");
                }
            }).start();
        }

        @JavascriptInterface
        public int getAppVersionCode() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
            } catch (Exception ignored) {
                return 0;
            }
        }

        @JavascriptInterface
        public String getAppVersionName() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception ignored) {
                return "";
            }
        }

        @JavascriptInterface
        public void downloadAndInstallApk(String serviceUrl, String token, String fileName) {
            new Thread(() -> downloadApkAndInstall(serviceUrl, token, fileName)).start();
        }
    }

    private void downloadApkAndInstall(String serviceUrl, String token, String apkName) {
        HttpURLConnection connection = null;
        try {
            URL base = new URL(serviceUrl == null ? "" : serviceUrl.replaceAll("/+$", ""));
            String protocol = base.getProtocol();
            if (!("http".equalsIgnoreCase(protocol) || "https".equalsIgnoreCase(protocol)) || base.getHost() == null || base.getHost().isEmpty()) {
                throw new IOException("服务地址配置无效");
            }
            URL target = new URL(base.toString() + "/v1/update/download?fileName=" + URLEncoder.encode(apkName == null || apkName.isEmpty() ? "latest.apk" : apkName, "UTF-8"));
            connection = (HttpURLConnection) target.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(20000);
            connection.setReadTimeout(120000);
            connection.setUseCaches(false);
            connection.setInstanceFollowRedirects(true);
            if (token != null && !token.isEmpty()) {
                connection.setRequestProperty("Authorization", "Bearer " + token);
            }
            int status = connection.getResponseCode();
            if (status != 200) {
                throw new IOException("安装包下载失败（HTTP " + status + "）");
            }
            long total = connection.getContentLengthLong();
            File updateDir = new File(getCacheDir(), "app_updates");
            if (!updateDir.exists() && !updateDir.mkdirs()) throw new IOException("无法创建更新缓存目录");
            File apkFile = new File(updateDir, "shiguangji-update.apk");
            final int[] lastPct = {0};
            try (java.io.InputStream input = connection.getInputStream(); FileOutputStream output = new FileOutputStream(apkFile)) {
                byte[] buffer = new byte[8192];
                long read = 0;
                int len;
                while ((len = input.read(buffer)) != -1) {
                    output.write(buffer, 0, len);
                    read += len;
                    if (total > 0) {
                        int pct = (int) (read * 100 / total);
                        if (pct != lastPct[0]) {
                            lastPct[0] = pct;
                            int p = pct;
                            evaluateJavascript("window.onNativeUpdateProgress&&window.onNativeUpdateProgress(" + p + ")");
                        }
                    }
                }
            }
            Uri apkUri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", apkFile);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            runOnUiThread(() -> {
                try {
                    startActivity(intent);
                    evaluateJavascript("window.onNativeUpdateReady&&window.onNativeUpdateReady(" + JSONObject.quote("安装包已下载完成") + ")");
                } catch (Exception error) {
                    evaluateJavascript("window.onNativeUpdateReady&&window.onNativeUpdateReady(" + JSONObject.quote("无法打开安装界面，请检查是否允许安装未知来源应用") + ")");
                }
            });
        } catch (Exception error) {
            evaluateJavascript("window.onNativeUpdateFailed&&window.onNativeUpdateFailed(" + JSONObject.quote(error.getMessage() == null ? "下载安装失败" : error.getMessage()) + ")");
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void checkBackupConnectionFromBridge(String serviceUrl, String token) {
        rememberServiceUrlPrivate(serviceUrl);
        HttpURLConnection connection = null;
        try {
            URL base = new URL(serviceUrl == null ? "" : serviceUrl.replaceAll("/+$", ""));
            String protocol = base.getProtocol();
            if (!("http".equalsIgnoreCase(protocol) || "https".equalsIgnoreCase(protocol)) || base.getHost() == null || base.getHost().isEmpty() || token == null || token.isEmpty()) {
                throw new IOException("备份服务配置无效");
            }
            connection = (HttpURLConnection) new URL(base.toString() + "/v1/backup/status").openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(15000);
            connection.setUseCaches(false);
            connection.setRequestProperty("Authorization", "Bearer " + token);
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) throw new IOException("电脑连接检查失败（HTTP " + status + ")");
            sendBackupConnectionResult(true, "连接成功");
        } catch (Exception error) {
            sendBackupConnectionResult(false, error.getMessage() == null ? "电脑未连接" : error.getMessage());
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void sendBackupConnectionResult(boolean success, String message) {
        evaluateJavascript("window.onNativeBackupConnectionChecked&&window.onNativeBackupConnectionChecked(" + success + "," + JSONObject.quote(message) + ")");
    }

    private void uploadBackupFromBridge(String json, String serviceUrl, String token) {
        rememberServiceUrlPrivate(serviceUrl);
        HttpURLConnection connection = null;
        try {
            byte[] bytes = (json == null ? "" : json).getBytes(StandardCharsets.UTF_8);
            if (bytes.length > 64L * 1024L * 1024L) throw new IOException("备份超过 64MB 限制");
            URL base = new URL(serviceUrl == null ? "" : serviceUrl.replaceAll("/+$", ""));
            String protocol = base.getProtocol();
            if (!("http".equalsIgnoreCase(protocol) || "https".equalsIgnoreCase(protocol)) || base.getHost() == null || base.getHost().isEmpty()) {
                throw new IOException("备份服务地址无效");
            }
            URL target = new URL(base.toString() + "/v1/backup");
            connection = (HttpURLConnection) target.openConnection();
            connection.setRequestMethod("PUT");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(120000);
            connection.setUseCaches(false);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            if (token != null && !token.isEmpty()) connection.setRequestProperty("Authorization", "Bearer " + token);
            connection.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream output = connection.getOutputStream()) { output.write(bytes); }
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) {
                InputStream stream = connection.getErrorStream();
                ByteArrayOutputStream error = new ByteArrayOutputStream();
                if (stream != null) try (InputStream input = stream) {
                    byte[] buffer = new byte[1024];
                    int count, remaining = 4096;
                    while (remaining > 0 && (count = input.read(buffer, 0, Math.min(buffer.length, remaining))) != -1) { error.write(buffer, 0, count); remaining -= count; }
                }
                String detail = error.toString("UTF-8").trim();
                throw new IOException("电脑备份上传失败（HTTP " + status + ")" + (detail.isEmpty() ? "" : "：" + detail));
            }
            rememberCloudSyncProgress();
            sendBackupUploadResult(true, "电脑备份上传成功");
        } catch (Exception error) {
            sendBackupUploadResult(false, error.getMessage() == null ? "电脑备份上传失败" : error.getMessage());
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void sendBackupUploadResult(boolean success, String message) {
        evaluateJavascript("window.onNativeBackupUploaded&&window.onNativeBackupUploaded(" + success + "," + JSONObject.quote(message) + ")");
    }

    private void saveAutomaticBackupPrivate(String json, String requestedName) {
        try {
            if (!BACKUP_NAME.equals(requestedName)) throw new IOException("备份文件名不安全");
            byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
            JSONObject parsed = new JSONObject(json);
            int newCount = backupDataCount(parsed);
            boolean allowEmpty = parsed.optJSONObject("backupMeta") != null && parsed.optJSONObject("backupMeta").optBoolean("allowEmpty", false);
            if (newCount == 0 && !allowEmpty) {
                byte[] previous = readPrivateBackupBytes();
                if (previous != null && backupDataCount(new JSONObject(new String(previous, StandardCharsets.UTF_8))) > 0) {
                    throw new IOException("检测到数据异常变空，已拒绝覆盖原备份");
                }
            }
            writePrivateBackup(bytes);
            evaluateJavascript("window.onNativeAutomaticBackupSaved&&window.onNativeAutomaticBackupSaved(true," + JSONObject.quote("已保存到应用私有存储") + ")");
        } catch (Exception error) {
            evaluateJavascript("window.onNativeAutomaticBackupSaved&&window.onNativeAutomaticBackupSaved(false," + JSONObject.quote(error.getMessage() == null ? "备份保存失败" : error.getMessage()) + ")");
        }
    }

    private File privateBackupFile() {
        return new File(new File(getFilesDir(), PRIVATE_BACKUP_DIR), BACKUP_NAME);
    }

    private byte[] readPrivateBackupBytes() {
        try {
            return readFile(privateBackupFile());
        } catch (Exception ignored) {
            return null;
        }
    }

    private void writePrivateBackup(byte[] bytes) throws Exception {
        File file = privateBackupFile();
        File directory = file.getParentFile();
        if (directory != null && !directory.exists() && !directory.mkdirs()) throw new IOException("无法创建应用私有备份目录");
        try (FileOutputStream output = new FileOutputStream(file, false)) {
            output.write(bytes);
            output.flush();
            output.getFD().sync();
        }
        verifyBackup(bytes, readPrivateBackupBytes());
    }

    private int backupDataCount(JSONObject backup) throws IOException {
        try {
            JSONArray entries = backup.getJSONArray("entries");
            JSONArray attachments = backup.getJSONArray("attachments");
            JSONArray exportAttachments = backup.optJSONArray("exportAttachments");
            return entries.length() + attachments.length() + (exportAttachments == null ? 0 : exportAttachments.length());
        } catch (Exception error) {
            throw new IOException("备份数据不完整");
        }
    }

    private byte[] readFile(File file) throws Exception {
        if (!file.isFile()) return null;
        try (InputStream input = new FileInputStream(file); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            copyStream(input, output);
            return output.toByteArray();
        }
    }

    private void verifyBackup(byte[] expected, byte[] actual) throws Exception {
        if (actual == null || actual.length != expected.length || !MessageDigest.isEqual(
                MessageDigest.getInstance("SHA-256").digest(expected),
                MessageDigest.getInstance("SHA-256").digest(actual))) {
            throw new IOException("备份写入校验失败");
        }
    }

    private void runWordConversion(String base64, String sourceFileName, String outputFileName) {
        try {
            byte[] docx = Base64.decode(base64, Base64.DEFAULT);
            conversionProgress(0, "准备上传");
            HttpURLConnection upload = openConversionConnection(conversionServiceUrl + "/v1/jobs", "POST");
            upload.setRequestProperty("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
            upload.setRequestProperty("X-File-Name", sourceFileName == null ? "document.docx" : sourceFileName);
            upload.setFixedLengthStreamingMode(docx.length);
            conversionConnection = upload;
            upload.connect();
            final long uploadStartedAt = System.currentTimeMillis();
            long lastUploadReportAt = 0;
            try (OutputStream output = upload.getOutputStream()) {
                int offset = 0;
                while (offset < docx.length) {
                    if (conversionCancelled) throw new IOException("已取消转换");
                    int count = Math.min(32768, docx.length - offset);
                    output.write(docx, offset, count);
                    offset += count;
                    long now = System.currentTimeMillis();
                    boolean isLast = offset >= docx.length;
                    if (isLast || now - lastUploadReportAt >= 250) {
                        lastUploadReportAt = now;
                        int pct = Math.min(60, Math.round(offset * 60f / Math.max(1, docx.length)));
                        conversionProgress(pct, uploadStageText(docx.length, offset, uploadStartedAt, now));
                    }
                }
            }
            JSONObject created = new JSONObject(readHttpResponse(upload));
            conversionJobId = created.optString("jobId");
            if (conversionJobId.isEmpty()) throw new IOException("转换服务未返回任务编号");
            upload.disconnect();
            conversionConnection = null;
            for (;;) {
                if (conversionCancelled) throw new IOException("已取消转换");
                Thread.sleep(1000);
                HttpURLConnection poll = openConversionConnection(jobUrl(), "GET");
                conversionConnection = poll;
                JSONObject job = new JSONObject(readHttpResponse(poll));
                poll.disconnect();
                conversionConnection = null;
                String status = job.optString("status").toLowerCase(Locale.ROOT);
                int serverProgress = Math.max(0, Math.min(100, job.optInt("progress", 0)));
                int progress = Math.max(60, Math.min(95, Math.round(60 + serverProgress * 0.35f)));
                conversionProgress(progress, normalizeConversionStage(job.optString("stage", ""), serverProgress, status));
                if (status.equals("failed") || status.equals("error")) throw new IOException(job.optString("error", "转换服务处理失败"));
                if (status.equals("cancelled") || status.equals("canceled")) throw new IOException("已取消转换");
                if (status.equals("completed") || status.equals("succeeded") || status.equals("success")) break;
            }
            HttpURLConnection download = openConversionConnection(jobUrl() + "/result", "GET");
            conversionConnection = download;
            if (download.getResponseCode() < 200 || download.getResponseCode() >= 300) throw new IOException("下载 PDF 失败（HTTP " + download.getResponseCode() + "）");
            long expectedPdfBytes = download.getContentLengthLong();
            conversionProgress(95, "正在回传 PDF");
            String savedName;
            try (InputStream input = download.getInputStream()) {
                savedName = writePdfStreamToDownloads(input, outputFileName, expectedPdfBytes, System.currentTimeMillis());
            }
            conversionProgress(100, "转换完成");
            conversionFinished(true, savedName);
        } catch (Exception error) {
            conversionFinished(false, conversionCancelled ? "已取消转换" : (error.getMessage() == null ? "转换失败" : error.getMessage()));
        } finally {
            HttpURLConnection connection = conversionConnection;
            if (connection != null) connection.disconnect();
            conversionConnection = null;
            conversionJobId = null;
            conversionToken = "";
        }
    }

    private HttpURLConnection openConversionConnection(String address, String method) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setRequestMethod(method);
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(600000);
        connection.setUseCaches(false);
        if (!conversionToken.isEmpty()) connection.setRequestProperty("Authorization", "Bearer " + conversionToken);
        if ("POST".equals(method)) connection.setDoOutput(true);
        return connection;
    }

    private String readHttpResponse(HttpURLConnection connection) throws IOException {
        int status = connection.getResponseCode();
        InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        if (stream != null) try (InputStream input = stream) { byte[] buffer = new byte[8192]; int count; while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count); }
        String body = output.toString("UTF-8");
        if (status < 200 || status >= 300) throw new IOException("转换服务请求失败（HTTP " + status + ")" + (body.isEmpty() ? "" : "：" + body));
        return body;
    }

    private String jobUrl() throws Exception { return conversionServiceUrl + "/v1/jobs/" + URLEncoder.encode(conversionJobId, "UTF-8"); }

    private void deleteConversionJob() {
        if (conversionJobId == null || conversionJobId.isEmpty()) return;
        try { HttpURLConnection connection = openConversionConnection(jobUrl(), "DELETE"); connection.getResponseCode(); connection.disconnect(); } catch (Exception ignored) { }
    }

    private void conversionProgress(int progress, String stage) { evaluateJavascript("window.onNativeWordConversionProgress&&window.onNativeWordConversionProgress(" + progress + "," + JSONObject.quote(stage) + ")"); }
    private void conversionFinished(boolean success, String message) { evaluateJavascript("window.onNativeWordConversionFinished&&window.onNativeWordConversionFinished(" + success + "," + JSONObject.quote(message) + ")"); }

    private String writeJsonToDownloads(String json, String requestedName) throws Exception {
        String base = requestedName == null || requestedName.trim().isEmpty() ? BACKUP_NAME : requestedName;
        String stamp = new java.text.SimpleDateFormat("yyyyMMdd-HHmmss", java.util.Locale.US).format(new java.util.Date());
        String fileName = sanitizeFileName(base);
        if (!fileName.toLowerCase(java.util.Locale.ROOT).endsWith(".json")) fileName += ".json";
        fileName = fileName.replaceAll("\\.json$", "") + "-" + stamp + ".json";
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        Uri folder = getSavedDownloadFolder();
        if (folder != null) {
            try {
                Uri documentFolder = android.provider.DocumentsContract.buildDocumentUriUsingTree(folder, android.provider.DocumentsContract.getTreeDocumentId(folder));
                Uri fileUri = android.provider.DocumentsContract.createDocument(getContentResolver(), documentFolder, "application/json", fileName);
                if (fileUri == null) throw new IOException("无法在所选目录创建文件");
                try (OutputStream output = getContentResolver().openOutputStream(fileUri)) { output.write(bytes); }
                return fileName + "（" + getFolderName(folder) + "）";
            } catch (Exception error) { clearSavedDownloadFolder(); throw new IOException("默认下载目录已失效，请重新选择"); }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName); values.put(MediaStore.MediaColumns.MIME_TYPE, "application/json"); values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS); values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("无法创建下载文件");
            try (OutputStream output = getContentResolver().openOutputStream(uri)) { output.write(bytes); }
            values.clear(); values.put(MediaStore.MediaColumns.IS_PENDING, 0); getContentResolver().update(uri, values, null, null);
        } else {
            File directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!directory.exists() && !directory.mkdirs()) throw new IOException("无法打开下载目录");
            try (OutputStream output = new FileOutputStream(new File(directory, fileName))) { output.write(bytes); }
        }
        return fileName;
    }

    private String writePdfStreamToDownloads(InputStream input, String requestedName, long expectedBytes, long downloadStartedAt) throws Exception {
        String fileName = sanitizeFileName(requestedName);
        if (!fileName.toLowerCase(Locale.ROOT).endsWith(".pdf")) fileName += ".pdf";
        Uri folder = getSavedDownloadFolder();
        if (folder != null) {
            try {
                Uri documentFolder = android.provider.DocumentsContract.buildDocumentUriUsingTree(folder, android.provider.DocumentsContract.getTreeDocumentId(folder));
                Uri fileUri = android.provider.DocumentsContract.createDocument(getContentResolver(), documentFolder, "application/pdf", fileName);
                if (fileUri == null) throw new IOException("无法在所选目录创建文件");
                try (OutputStream output = getContentResolver().openOutputStream(fileUri)) { copyPdfStreamWithProgress(input, output, expectedBytes, downloadStartedAt); }
                return fileName + "（" + getFolderName(folder) + "）";
            } catch (Exception error) { clearSavedDownloadFolder(); throw new IOException("默认下载目录已失效，请重新选择"); }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName); values.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf"); values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS); values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("无法创建下载文件");
            try (OutputStream output = getContentResolver().openOutputStream(uri)) { copyPdfStreamWithProgress(input, output, expectedBytes, downloadStartedAt); }
            values.clear(); values.put(MediaStore.MediaColumns.IS_PENDING, 0); getContentResolver().update(uri, values, null, null);
        } else {
            File directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!directory.exists() && !directory.mkdirs()) throw new IOException("无法打开下载目录");
            try (OutputStream output = new FileOutputStream(new File(directory, fileName))) { copyPdfStreamWithProgress(input, output, expectedBytes, downloadStartedAt); }
        }
        return fileName;
    }

    private void copyPdfStreamWithProgress(InputStream input, OutputStream output, long expectedBytes, long downloadStartedAt) throws IOException {
        if (output == null) throw new IOException("无法写入下载文件");
        byte[] buffer = new byte[32768];
        long done = 0;
        long lastReportAt = 0;
        int count;
        while ((count = input.read(buffer)) != -1) {
            if (conversionCancelled) throw new IOException("已取消转换");
            output.write(buffer, 0, count);
            done += count;
            long now = System.currentTimeMillis();
            if (now - lastReportAt >= 250 || expectedBytes <= 0 || done >= expectedBytes) {
                lastReportAt = now;
                conversionProgress(downloadPercent(expectedBytes, done), downloadStageText(expectedBytes, done, downloadStartedAt, now));
            }
        }
    }

    private int downloadPercent(long expectedBytes, long doneBytes) {
        if (expectedBytes > 0) return Math.min(99, Math.max(95, Math.round(95 + doneBytes * 4f / expectedBytes)));
        return 98;
    }

    private String uploadStageText(long totalBytes, long doneBytes, long startedAt, long now) {
        String size = "（" + formatBytes(doneBytes) + " / " + formatBytes(totalBytes) + "）";
        long elapsed = now - startedAt;
        if (elapsed < 500) return "正在上传 Word" + size;
        return "正在上传 Word" + size + " · " + formatSpeed(doneBytes, elapsed);
    }

    private String downloadStageText(long expectedBytes, long doneBytes, long startedAt, long now) {
        String size = "（" + formatBytes(doneBytes) + (expectedBytes > 0 ? " / " + formatBytes(expectedBytes) : "") + "）";
        long elapsed = now - startedAt;
        if (elapsed < 500) return "正在回传 PDF" + size;
        return "正在回传 PDF" + size + " · " + formatSpeed(doneBytes, elapsed);
    }

    private String normalizeConversionStage(String raw, int serverProgress, String status) {
        if (raw == null) raw = "";
        String stage = raw.trim();
        if (stage.isEmpty()) return "正在转换排版";
        if (status.contains("queued") || stage.contains("等待")) return "正在排队等待转换";
        if (stage.contains("启动")) return "正在启动转换引擎";
        if (stage.contains("完成")) return "正在收尾";
        return "正在转换排版";
    }

    private String formatBytes(long bytes) {
        if (bytes <= 0) return "0";
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1048576) return String.format(Locale.US, "%.0f KB", bytes / 1024.0);
        return String.format(Locale.US, "%.1f MB", bytes / 1048576.0);
    }

    private String formatSpeed(long bytes, long elapsedMs) {
        if (elapsedMs <= 0) return "";
        double bytesPerSecond = bytes * 1000.0 / elapsedMs;
        if (bytesPerSecond < 1048576) return String.format(Locale.US, "%.0f KB/s", bytesPerSecond / 1024.0);
        return String.format(Locale.US, "%.1f MB/s", bytesPerSecond / 1048576.0);
    }

    private void copyStream(InputStream input, OutputStream output) throws IOException { if (output == null) throw new IOException("无法写入下载文件"); byte[] buffer = new byte[32768]; int count; while ((count = input.read(buffer)) != -1) { if (conversionCancelled) throw new IOException("已取消转换"); output.write(buffer, 0, count); } }

    private String sanitizeFileName(String fileName) {
        String value = fileName == null ? "外部文档.docx" : fileName.replaceAll("[\\\\/:*?\"<>|]", "").trim();
        return value.isEmpty() ? "外部文档.docx" : value;
    }

    private static class DocxImage {
        byte[] bytes;
        String extension;
        String relationshipId;
        int number;
        long width;
        long height;
    }

    private SharedPreferences downloadPreferences() {
        return getSharedPreferences(DOWNLOAD_PREFS, MODE_PRIVATE);
    }

    private Uri getSavedDownloadFolder() {
        String value = downloadPreferences().getString(DOWNLOAD_FOLDER_URI, null);
        return value == null || value.isEmpty() ? null : Uri.parse(value);
    }

    private void clearSavedDownloadFolder() {
        downloadPreferences().edit().remove(DOWNLOAD_FOLDER_URI).apply();
    }

    private void rememberServiceUrlPrivate(String serviceUrl) {
        try {
            String value = serviceUrl == null ? "" : serviceUrl.trim().replaceAll("/+$", "");
            if (!value.matches("^https?://[^\\s]+$")) return;
            downloadPreferences().edit().putString(SERVICE_URL_PREF, value).apply();
        } catch (Exception ignored) {
        }
    }

    private void rememberCloudSyncProgress() {
        try {
            File file = privateBackupFile();
            if (file == null || !file.isFile()) return;
            downloadPreferences().edit()
                    .putLong(CLOUD_SYNC_MTIME, file.lastModified())
                    .putLong(CLOUD_SYNC_SIZE, file.length())
                    .apply();
        } catch (Exception ignored) {
        }
    }

    private String getFolderName(Uri uri) {
        String path = uri.getLastPathSegment();
        if (path == null || path.isEmpty()) return "已选文件夹";
        int slash = path.lastIndexOf('/');
        String name = slash >= 0 ? path.substring(slash + 1) : path;
        int colon = name.lastIndexOf(':');
        return colon >= 0 && colon < name.length() - 1 ? name.substring(colon + 1) : name;
    }

    private String writeDocxToDownloads(String json, String requestedName) throws Exception {
        String fileName = requestedName.endsWith(".docx") ? requestedName : requestedName + ".docx";
        ByteArrayOutputStream packageBytes = new ByteArrayOutputStream();
        createDocxPackage(new JSONObject(json), packageBytes);
        byte[] bytes = packageBytes.toByteArray();
        Uri folder = getSavedDownloadFolder();
        if (folder != null) {
            try {
                Uri documentFolder = android.provider.DocumentsContract.buildDocumentUriUsingTree(folder, android.provider.DocumentsContract.getTreeDocumentId(folder));
                Uri fileUri = android.provider.DocumentsContract.createDocument(getContentResolver(), documentFolder, "application/vnd.openxmlformats-officedocument.wordprocessingml.document", fileName);
                if (fileUri == null) throw new IOException("无法在所选目录创建文件");
                try (OutputStream output = getContentResolver().openOutputStream(fileUri)) {
                    if (output == null) throw new IOException("无法写入所选目录");
                    output.write(bytes);
                }
                return fileName + "（" + getFolderName(folder) + "）";
            } catch (Exception error) {
                clearSavedDownloadFolder();
                throw new IOException("默认下载目录已失效，请重新选择");
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            values.put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("无法创建下载文件");
            try (OutputStream output = getContentResolver().openOutputStream(uri)) {
                if (output == null) throw new IOException("无法写入下载文件");
                output.write(bytes);
            }
            values.clear();
            values.put(MediaStore.MediaColumns.IS_PENDING, 0);
            getContentResolver().update(uri, values, null, null);
        } else {
            File directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!directory.exists() && !directory.mkdirs()) throw new IOException("无法打开下载目录");
            try (OutputStream output = new FileOutputStream(new File(directory, fileName))) {
                output.write(bytes);
            }
        }
        return fileName;
    }

    private String writePdfToDownloads(String json, String requestedName) throws Exception {
        String fileName = requestedName.endsWith(".pdf") ? requestedName : requestedName + ".pdf";
        ByteArrayOutputStream packageBytes = new ByteArrayOutputStream();
        createPdf(new JSONObject(json), packageBytes);
        byte[] bytes = packageBytes.toByteArray();
        Uri folder = getSavedDownloadFolder();
        if (folder != null) {
            try {
                Uri documentFolder = android.provider.DocumentsContract.buildDocumentUriUsingTree(folder, android.provider.DocumentsContract.getTreeDocumentId(folder));
                Uri fileUri = android.provider.DocumentsContract.createDocument(getContentResolver(), documentFolder, "application/pdf", fileName);
                if (fileUri == null) throw new IOException("无法在所选目录创建文件");
                try (OutputStream output = getContentResolver().openOutputStream(fileUri)) {
                    if (output == null) throw new IOException("无法写入所选目录");
                    output.write(bytes);
                }
                return fileName + "（" + getFolderName(folder) + "）";
            } catch (Exception error) {
                clearSavedDownloadFolder();
                throw new IOException("默认下载目录已失效，请重新选择");
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            values.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("无法创建下载文件");
            try (OutputStream output = getContentResolver().openOutputStream(uri)) {
                if (output == null) throw new IOException("无法写入下载文件");
                output.write(bytes);
            }
            values.clear();
            values.put(MediaStore.MediaColumns.IS_PENDING, 0);
            getContentResolver().update(uri, values, null, null);
        } else {
            File directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!directory.exists() && !directory.mkdirs()) throw new IOException("无法打开下载目录");
            try (OutputStream output = new FileOutputStream(new File(directory, fileName))) { output.write(bytes); }
        }
        return fileName;
    }

    private void createPdf(JSONObject root, OutputStream output) throws Exception {
        if ("external-word".equals(root.optString("mode"))) {
            createExternalWordPdf(root, output);
            return;
        }
        JSONArray records = root.getJSONArray("records");
        PdfDocument pdf = new PdfDocument();
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.rgb(42, 38, 33));
        try {
            for (int i = 0; i < records.length(); i++) {
                JSONObject record = records.getJSONObject(i);
                PdfDocument.Page page = pdf.startPage(new PdfDocument.PageInfo.Builder(595, 842, i + 1).create());
                Canvas canvas = page.getCanvas();
                canvas.drawColor(Color.WHITE);
                float y = 48;
                paint.setTextAlign(Paint.Align.CENTER);
                paint.setFakeBoldText(true);
                paint.setTextSize(18);
                canvas.drawText(root.optString("name") + " · 第" + (i + 1) + "条", 297.5f, y, paint);
                y += 30;
                paint.setTextAlign(Paint.Align.LEFT);
                paint.setFakeBoldText(false);
                paint.setTextSize(11);
                String meta = "日期：" + valueOrBlank(record.optString("date")) + "    金额：" + (record.optString("amount").isEmpty() ? "未填写" : "¥" + record.optString("amount")) + "    类别：" + valueOrBlank(record.optString("category"));
                canvas.drawText(meta, 40, y, paint);
                y += 24;
                JSONArray expense = record.optJSONArray("expense"), invoice = record.optJSONArray("invoice");
                int imageCount = countImages(expense) + countImages(invoice);
                float imageHeight = imageCount == 0 ? 0 : Math.min(205, 430f / imageCount);
                y = drawPdfSection(canvas, paint, expense, "① 消费截图", y, imageHeight);
                y = drawPdfSection(canvas, paint, invoice, "② 发票", y, imageHeight);
                paint.setFakeBoldText(true);
                paint.setTextSize(13);
                canvas.drawText("③ 备注", 40, y, paint);
                y += 20;
                paint.setFakeBoldText(false);
                paint.setTextSize(11);
                drawWrappedPdfText(canvas, paint, record.optString("note").isEmpty() ? "无" : record.optString("note"), 40, y, 515, 16, 810);
                pdf.finishPage(page);
            }
            pdf.writeTo(output);
        } finally {
            pdf.close();
        }
    }

    private void createExternalWordPdf(JSONObject root, OutputStream output) throws Exception {
        JSONArray blocks = root.getJSONArray("blocks");
        PdfDocument pdf = new PdfDocument();
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.rgb(42, 38, 33));
        paint.setTextSize(11);
        PdfDocument.Page page = null;
        Canvas canvas = null;
        float y = 48;
        int pageNumber = 0;
        try {
            for (int i = 0; i < blocks.length(); i++) {
                JSONObject block = blocks.getJSONObject(i);
                if (page == null) {
                    page = pdf.startPage(new PdfDocument.PageInfo.Builder(595, 842, ++pageNumber).create());
                    canvas = page.getCanvas();
                    canvas.drawColor(Color.WHITE);
                }
                if ("image".equals(block.optString("type"))) {
                    Bitmap bitmap = decodePdfDataImage(block.optString("data"), 515, 700);
                    if (bitmap == null) continue;
                    float scale = Math.min(515f / bitmap.getWidth(), 700f / bitmap.getHeight());
                    float width = bitmap.getWidth() * scale, height = bitmap.getHeight() * scale;
                    if (y + height > 810 && y > 48) {
                        pdf.finishPage(page);
                        page = pdf.startPage(new PdfDocument.PageInfo.Builder(595, 842, ++pageNumber).create());
                        canvas = page.getCanvas();
                        canvas.drawColor(Color.WHITE);
                        y = 48;
                    }
                    float left = 40 + (515 - width) / 2;
                    canvas.drawBitmap(bitmap, null, new RectF(left, y, left + width, y + height), paint);
                    bitmap.recycle();
                    y += height + 12;
                } else {
                    String text = block.optString("text");
                    for (String paragraph : wrapPdfLines(paint, text, 515)) {
                        if (y + 17 > 810) {
                            pdf.finishPage(page);
                            page = pdf.startPage(new PdfDocument.PageInfo.Builder(595, 842, ++pageNumber).create());
                            canvas = page.getCanvas();
                            canvas.drawColor(Color.WHITE);
                            y = 48;
                        }
                        canvas.drawText(paragraph, 40, y, paint);
                        y += 17;
                    }
                    y += 5;
                }
            }
            if (page != null) pdf.finishPage(page);
            if (pageNumber == 0) throw new IOException("Word 文档中没有可转换内容");
            pdf.writeTo(output);
        } finally {
            pdf.close();
        }
    }

    private List<String> wrapPdfLines(Paint paint, String text, float width) {
        List<String> lines = new ArrayList<>();
        String remaining = text == null ? "" : text;
        while (!remaining.isEmpty()) {
            int count = paint.breakText(remaining, true, width, null);
            if (count <= 0) break;
            lines.add(remaining.substring(0, count));
            remaining = remaining.substring(count);
        }
        if (lines.isEmpty()) lines.add("");
        return lines;
    }

    private Bitmap decodePdfDataImage(String data, int requestedWidth, int requestedHeight) {
        try {
            int comma = data.indexOf(',');
            byte[] bytes = Base64.decode(comma >= 0 ? data.substring(comma + 1) : data, Base64.DEFAULT);
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = calculateInSampleSize(bounds.outWidth, bounds.outHeight, requestedWidth, requestedHeight);
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
        } catch (IllegalArgumentException error) {
            return null;
        }
    }

    private float drawPdfSection(Canvas canvas, Paint paint, JSONArray files, String title, float y, float imageHeight) {
        paint.setFakeBoldText(true);
        paint.setTextSize(13);
        canvas.drawText(title, 40, y, paint);
        y += 18;
        paint.setFakeBoldText(false);
        boolean added = false;
        if (files != null) for (int i = 0; i < files.length(); i++) {
            String data = files.optJSONObject(i).optString("data");
            if (data.isEmpty()) continue;
            int comma = data.indexOf(',');
            byte[] bytes = Base64.decode(comma >= 0 ? data.substring(comma + 1) : data, Base64.DEFAULT);
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) continue;
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = calculateInSampleSize(bounds.outWidth, bounds.outHeight, 515, Math.max(1, Math.round(imageHeight)));
            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
            if (bitmap == null) continue;
            float scale = Math.min(515f / bitmap.getWidth(), imageHeight / bitmap.getHeight());
            float width = bitmap.getWidth() * scale, height = bitmap.getHeight() * scale;
            float left = 40 + (515 - width) / 2;
            canvas.drawBitmap(bitmap, null, new RectF(left, y, left + width, y + height), paint);
            bitmap.recycle();
            y += height + 8;
            added = true;
        }
        if (!added) {
            paint.setTextSize(10);
            canvas.drawText("未添加", 40, y, paint);
            y += 18;
        }
        return y + 4;
    }

    private int calculateInSampleSize(int width, int height, int targetWidth, int targetHeight) {
        int sampleSize = 1;
        while (width / (sampleSize * 2) >= targetWidth || height / (sampleSize * 2) >= targetHeight) {
            sampleSize *= 2;
        }
        return sampleSize;
    }

    private void drawWrappedPdfText(Canvas canvas, Paint paint, String text, float x, float y, float width, float lineHeight, float maxY) {
        for (String paragraph : text.split("\\n", -1)) {
            StringBuilder line = new StringBuilder();
            for (int i = 0; i < paragraph.length(); i++) {
                char c = paragraph.charAt(i);
                if (paint.measureText(line.toString() + c) > width) {
                    if (y > maxY) return;
                    canvas.drawText(line.toString(), x, y, paint);
                    y += lineHeight;
                    line.setLength(0);
                }
                line.append(c);
            }
            if (y > maxY) return;
            canvas.drawText(line.length() == 0 ? " " : line.toString(), x, y, paint);
            y += lineHeight;
        }
    }

    private void createDocxPackage(JSONObject root, OutputStream output) throws Exception {
        if ("invoices-a5".equals(root.optString("mode"))) {
            createInvoiceDocxPackage(root, output);
            return;
        }
        JSONArray records = root.getJSONArray("records");
        List<DocxImage> images = new ArrayList<>();
        StringBuilder body = new StringBuilder();
        int imageNumber = 1;
        for (int i = 0; i < records.length(); i++) {
            JSONObject record = records.getJSONObject(i);
            body.append(paragraph(root.optString("name") + " · 第" + (i + 1) + "条", true, 32, "center"));
            String meta = "日期：" + valueOrBlank(record.optString("date")) + "    金额：" + (record.optString("amount").isEmpty() ? "未填写" : "¥" + record.optString("amount")) + "    类别：" + valueOrBlank(record.optString("category"));
            body.append(paragraph(meta, false, 21, "left"));
            JSONArray expenseFiles = record.optJSONArray("expense");
            JSONArray invoiceFiles = record.optJSONArray("invoice");
            int imageCount = countImages(expenseFiles) + countImages(invoiceFiles);
            int pdfLines = countPdfFiles(expenseFiles) + countPdfFiles(invoiceFiles);
            int emptySections = (countImages(expenseFiles) == 0 ? 1 : 0) + (countImages(invoiceFiles) == 0 ? 1 : 0);
            String note = record.optString("note");
            int noteFontSize = note.length() > 760 ? 14 : note.length() > 380 ? 17 : 22;
            int charsPerLine = noteFontSize <= 14 ? 58 : noteFontSize <= 17 ? 48 : 38;
            int noteLines = Math.max(1, (note.length() + charsPerLine - 1) / charsPerLine);
            long fixedHeight = 1650000L + noteLines * (noteFontSize <= 14 ? 145000L : noteFontSize <= 17 ? 170000L : 205000L)
                    + pdfLines * 255000L + emptySections * 255000L + imageCount * 90000L;
            long availableImageHeight = Math.max(120000L, 9300000L - fixedHeight);
            long maxImageHeight = imageCount == 0 ? 120000L : Math.min(3657600L, availableImageHeight / imageCount);
            imageNumber = appendImageSection(body, images, expenseFiles, "① 消费截图", imageNumber, maxImageHeight);
            imageNumber = appendImageSection(body, images, invoiceFiles, "② 发票", imageNumber, maxImageHeight);
            body.append(paragraph("③ 备注", true, 24, "left"));
            body.append(paragraph(note.isEmpty() ? "无" : note, false, noteFontSize, "left"));
            if (i < records.length() - 1) body.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>");
        }
        String document = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><w:body>" + body + "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\" w:orient=\"portrait\"/><w:pgMar w:top=\"794\" w:right=\"794\" w:bottom=\"794\" w:left=\"794\" w:header=\"425\" w:footer=\"425\" w:gutter=\"0\"/></w:sectPr></w:body></w:document>";
        StringBuilder relationships = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
        for (DocxImage image : images) relationships.append("<Relationship Id=\"").append(image.relationshipId).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/image").append(image.number).append('.').append(image.extension).append("\"/>");
        relationships.append("</Relationships>");
        String contentTypes = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Default Extension=\"jpeg\" ContentType=\"image/jpeg\"/><Default Extension=\"jpg\" ContentType=\"image/jpeg\"/><Default Extension=\"png\" ContentType=\"image/png\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>";
        String rootRelationships = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>";
        try (ZipOutputStream zip = new ZipOutputStream(output)) {
            zipText(zip, "[Content_Types].xml", contentTypes);
            zipText(zip, "_rels/.rels", rootRelationships);
            zipText(zip, "word/document.xml", document);
            zipText(zip, "word/_rels/document.xml.rels", relationships.toString());
            for (DocxImage image : images) zipBytes(zip, "word/media/image" + image.number + "." + image.extension, image.bytes);
        }
    }

    private void createInvoiceDocxPackage(JSONObject root, OutputStream output) throws Exception {
        JSONArray invoiceFiles = root.getJSONArray("invoices");
        List<DocxImage> images = new ArrayList<>();
        StringBuilder body = new StringBuilder();
        for (int i = 0; i < invoiceFiles.length(); i++) {
            JSONObject file = invoiceFiles.getJSONObject(i);
            String data = file.getString("data");
            int comma = data.indexOf(',');
            byte[] bytes = Base64.decode(comma >= 0 ? data.substring(comma + 1) : data, Base64.DEFAULT);
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
            int pixelWidth = Math.max(1, options.outWidth), pixelHeight = Math.max(1, options.outHeight);
            double scale = Math.min(4752000d / pixelWidth, 6984000d / pixelHeight);
            DocxImage image = new DocxImage();
            image.bytes = bytes;
            image.extension = data.startsWith("data:image/png") ? "png" : "jpg";
            image.relationshipId = "rId" + (i + 1);
            image.number = i + 1;
            image.width = Math.max(1, Math.round(pixelWidth * scale));
            image.height = Math.max(1, Math.round(pixelHeight * scale));
            images.add(image);
            body.append(imageParagraph(image));
            if (i < invoiceFiles.length() - 1) body.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>");
        }
        String document = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><w:body>" + body + "<w:sectPr><w:pgSz w:w=\"8391\" w:h=\"11906\" w:orient=\"portrait\"/><w:pgMar w:top=\"454\" w:right=\"454\" w:bottom=\"454\" w:left=\"454\" w:header=\"0\" w:footer=\"0\" w:gutter=\"0\"/></w:sectPr></w:body></w:document>";
        StringBuilder relationships = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
        for (DocxImage image : images) relationships.append("<Relationship Id=\"").append(image.relationshipId).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/image").append(image.number).append('.').append(image.extension).append("\"/>");
        relationships.append("</Relationships>");
        String contentTypes = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Default Extension=\"jpg\" ContentType=\"image/jpeg\"/><Default Extension=\"png\" ContentType=\"image/png\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>";
        String rootRelationships = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>";
        try (ZipOutputStream zip = new ZipOutputStream(output)) {
            zipText(zip, "[Content_Types].xml", contentTypes);
            zipText(zip, "_rels/.rels", rootRelationships);
            zipText(zip, "word/document.xml", document);
            zipText(zip, "word/_rels/document.xml.rels", relationships.toString());
            for (DocxImage image : images) zipBytes(zip, "word/media/image" + image.number + "." + image.extension, image.bytes);
        }
    }

    private int countImages(JSONArray files) {
        if (files == null) return 0;
        int count = 0;
        for (int i = 0; i < files.length(); i++) if (!files.optJSONObject(i).optString("data").isEmpty()) count++;
        return count;
    }

    private int countPdfFiles(JSONArray files) {
        if (files == null) return 0;
        int count = 0;
        for (int i = 0; i < files.length(); i++) {
            JSONObject file = files.optJSONObject(i);
            if (file != null && file.optString("data").isEmpty() && file.optString("name").toLowerCase().endsWith(".pdf")) count++;
        }
        return count;
    }

    private int appendImageSection(StringBuilder body, List<DocxImage> images, JSONArray files, String title, int nextNumber, long maxImageHeight) throws Exception {
        body.append(paragraph(title, true, 24, "left"));
        boolean added = false;
        if (files != null) for (int i = 0; i < files.length(); i++) {
            JSONObject file = files.getJSONObject(i);
            String data = file.optString("data");
            if (data.isEmpty()) {
                if (file.optString("name").toLowerCase().endsWith(".pdf")) body.append(paragraph("PDF附件：" + file.optString("name"), false, 20, "left"));
                continue;
            }
            int comma = data.indexOf(',');
            byte[] bytes = Base64.decode(comma >= 0 ? data.substring(comma + 1) : data, Base64.DEFAULT);
            android.graphics.BitmapFactory.Options options = new android.graphics.BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
            int pixelWidth = Math.max(1, options.outWidth), pixelHeight = Math.max(1, options.outHeight);
            long maxWidth = 5943600L;
            double scale = Math.min((double) maxWidth / pixelWidth, (double) maxImageHeight / pixelHeight);
            DocxImage image = new DocxImage();
            image.bytes = bytes;
            image.extension = data.startsWith("data:image/png") ? "png" : "jpg";
            image.relationshipId = "rId" + nextNumber;
            image.number = nextNumber++;
            image.width = Math.max(1, Math.round(pixelWidth * scale));
            image.height = Math.max(1, Math.round(pixelHeight * scale));
            images.add(image);
            body.append(imageParagraph(image));
            added = true;
        }
        if (!added) body.append(paragraph("未添加", false, 20, "left"));
        return nextNumber;
    }

    private String imageParagraph(DocxImage image) {
        return "<w:p><w:pPr><w:jc w:val=\"center\"/><w:spacing w:after=\"120\"/></w:pPr><w:r><w:drawing><wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\"><wp:extent cx=\"" + image.width + "\" cy=\"" + image.height + "\"/><wp:docPr id=\"" + image.number + "\" name=\"图片 " + image.number + "\"/><a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><pic:pic><pic:nvPicPr><pic:cNvPr id=\"0\" name=\"图片\"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed=\"" + image.relationshipId + "\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"" + image.width + "\" cy=\"" + image.height + "\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>";
    }

    private String paragraph(String text, boolean bold, int halfPoints, String align) {
        String safe = xmlEscape(text).replace("\n", "</w:t><w:br/><w:t xml:space=\"preserve\">");
        return "<w:p><w:pPr><w:jc w:val=\"" + align + "\"/><w:spacing w:after=\"120\" w:line=\"300\" w:lineRule=\"auto\"/></w:pPr><w:r><w:rPr>" + (bold ? "<w:b/>" : "") + "<w:sz w:val=\"" + halfPoints + "\"/><w:szCs w:val=\"" + halfPoints + "\"/><w:rFonts w:eastAsia=\"Microsoft YaHei\"/></w:rPr><w:t xml:space=\"preserve\">" + safe + "</w:t></w:r></w:p>";
    }

    private String valueOrBlank(String value) { return value.isEmpty() ? "未填写" : value; }
    private String xmlEscape(String value) { return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;"); }
    private void zipText(ZipOutputStream zip, String name, String text) throws IOException { zipBytes(zip, name, text.getBytes(StandardCharsets.UTF_8)); }
    private void zipBytes(ZipOutputStream zip, String name, byte[] bytes) throws IOException { zip.putNextEntry(new ZipEntry(name)); zip.write(bytes); zip.closeEntry(); }

    private void openCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) == null) {
            sendPhotoResult(null, "设备上没有可用的相机应用");
            return;
        }
        try {
            pendingPhotoFile = File.createTempFile("travel_photo_", ".jpg", getCacheDir());
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", pendingPhotoFile);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, CAMERA_CAPTURE_REQUEST);
        } catch (IOException error) {
            sendPhotoResult(null, "无法创建照片文件");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            evaluateJavascript("window.onNativeLocationPermission&&window.onNativeLocationPermission(" + granted + ")");
        } else if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (granted) openCamera();
            else sendPhotoResult(null, "相机权限未开启");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (requestCode == DOWNLOAD_FOLDER_REQUEST) {
            if (resultCode != RESULT_OK || intent == null || intent.getData() == null) {
                evaluateJavascript("window.onNativeDownloadFolderChanged&&window.onNativeDownloadFolderChanged(false,'未更改默认下载目录')");
                return;
            }
            Uri uri = intent.getData();
            int flags = intent.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            try {
                getContentResolver().takePersistableUriPermission(uri, flags);
                downloadPreferences().edit().putString(DOWNLOAD_FOLDER_URI, uri.toString()).apply();
                evaluateJavascript("window.onNativeDownloadFolderChanged&&window.onNativeDownloadFolderChanged(true," + JSONObject.quote("默认下载目录已设为：" + getFolderName(uri)) + ")");
            } catch (Exception error) {
                evaluateJavascript("window.onNativeDownloadFolderChanged&&window.onNativeDownloadFolderChanged(false,'无法保存默认下载目录')");
            }
            return;
        }
        if (requestCode != CAMERA_CAPTURE_REQUEST) return;
        if (resultCode != RESULT_OK || pendingPhotoFile == null || !pendingPhotoFile.exists()) {
            sendPhotoResult(null, resultCode == RESULT_CANCELED ? null : "拍照失败");
            deletePendingPhoto();
            return;
        }
        try (FileInputStream input = new FileInputStream(pendingPhotoFile);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int length;
            while ((length = input.read(buffer)) != -1) output.write(buffer, 0, length);
            byte[] photoBytes = output.toByteArray();
            saveCapturedPhotoToGallery(photoBytes);
            sendPhotoResult(Base64.encodeToString(photoBytes, Base64.NO_WRAP), null);
        } catch (IOException error) {
            sendPhotoResult(null, "保存照片失败");
        } finally {
            deletePendingPhoto();
        }
    }

    private void saveCapturedPhotoToGallery(byte[] bytes) throws IOException {
        String fileName = "拾光记_" + System.currentTimeMillis() + ".jpg";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/拾光记");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("无法在相册中创建照片");
            try {
                try (OutputStream output = getContentResolver().openOutputStream(uri, "w")) {
                    if (output == null) throw new IOException("无法写入相册照片");
                    output.write(bytes);
                }
                values.clear();
                values.put(MediaStore.Images.Media.IS_PENDING, 0);
                getContentResolver().update(uri, values, null, null);
            } catch (IOException error) {
                getContentResolver().delete(uri, null, null);
                throw error;
            }
            return;
        }
        File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "拾光记");
        if (!directory.exists() && !directory.mkdirs()) throw new IOException("无法创建相册目录");
        File file = new File(directory, fileName);
        try (OutputStream output = new FileOutputStream(file)) {
            output.write(bytes);
        }
        MediaScannerConnection.scanFile(this, new String[]{file.getAbsolutePath()}, new String[]{"image/jpeg"}, null);
    }

    private void sendPhotoResult(String base64, String error) {
        String dataArg = base64 == null ? "null" : JSONObject.quote(base64);
        String errorArg = error == null ? "null" : JSONObject.quote(error);
        evaluateJavascript("window.onNativePhotoCaptured&&window.onNativePhotoCaptured(" + dataArg + "," + errorArg + ")");
    }

    private void evaluateJavascript(String script) {
        runOnUiThread(() -> systemWebView.evaluateJavascript(script, null));
    }

    private void deletePendingPhoto() {
        if (pendingPhotoFile != null) pendingPhotoFile.delete();
        pendingPhotoFile = null;
    }
}