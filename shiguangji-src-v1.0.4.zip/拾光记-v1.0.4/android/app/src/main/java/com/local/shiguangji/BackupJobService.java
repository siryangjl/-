package com.local.shiguangji;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/**
 * 系统级后台兜底上传：即使 App 进程被杀，系统也会周期性拉起本服务，
 * 检查本机私有备份文件是否有新数据，若有则补传到云端。
 *
 * 设计要点：
 * 1. 只有在"数据确实变了"（文件大小/修改时间/内容签名变化）时才真正上传，否则零网络请求；
 * 2. 只在已绑定邮箱（原生已保存账号 token）时才尝试；
 * 3. 间隔由系统调度，最短约 15 分钟，省电场景可能顺延，不保证整点；
 * 4. 强停 App 后系统会暂停本任务，直到用户下次手动打开一次才会恢复（Android 安全策略）。
 */
public class BackupJobService extends JobService {
    private static final int JOB_ID = 9105;
    private static final long PERIOD_MS = 15 * 60 * 1000L;
    private static final long MAX_UPLOAD_BYTES = 64L * 1024L * 1024L;

    private static final String DOWNLOAD_PREFS = "life_journey_download";
    private static final String KEY_DEVICE_TOKEN = "device_token";
    private static final String KEY_SERVICE_URL = "service_url";
    private static final String KEY_MTIME = "cloud_sync_mtime";
    private static final String KEY_SIZE = "cloud_sync_size";
    private static final String KEY_SHA = "cloud_sync_sha";

    private static final String DEFAULT_SERVICE_URL = "https://lj.facelightt.indevs.in";
    private static final String BACKUP_FILE_NAME = "拾光记-数据备份.json";

    public static void schedule(Context context) {
        try {
            JobScheduler scheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (scheduler == null) return;
            ComponentName componentName = new ComponentName(context, BackupJobService.class);
            JobInfo.Builder builder = new JobInfo.Builder(JOB_ID, componentName)
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPersisted(true)
                    .setPeriodic(PERIOD_MS);
            if (scheduler.getPendingJob(JOB_ID) == null) {
                scheduler.schedule(builder.build());
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public boolean onStartJob(JobParameters params) {
        new Thread(() -> {
            try {
                attemptCloudSync();
            } finally {
                jobFinished(params, false);
            }
        }).start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return false;
    }

    private void attemptCloudSync() {
        try {
            SharedPreferences prefs = getSharedPreferences(DOWNLOAD_PREFS, MODE_PRIVATE);
            String token = prefs.getString(KEY_DEVICE_TOKEN, "");
            if (token == null || token.isEmpty()) return;
            File backupFile = privateBackupFile();
            if (backupFile == null || !backupFile.isFile() || backupFile.length() <= 0) return;
            long mtime = backupFile.lastModified();
            long size = backupFile.length();
            if (mtime == prefs.getLong(KEY_MTIME, -1) && size == prefs.getLong(KEY_SIZE, -1)) return;
            if (size > MAX_UPLOAD_BYTES) return;

            byte[] bytes = readBytes(backupFile);
            if (bytes == null || bytes.length == 0) return;
            String sha = sha256(bytes);
            if (sha.equals(prefs.getString(KEY_SHA, ""))) {
                rememberSynced(prefs, mtime, size, sha);
                return;
            }

            String serviceUrl = prefs.getString(KEY_SERVICE_URL, "");
            if (serviceUrl == null || !serviceUrl.matches("^https?://[^\\s]+$")) {
                serviceUrl = DEFAULT_SERVICE_URL;
            }
            if (uploadBackup(serviceUrl, token, bytes)) {
                rememberSynced(prefs, mtime, size, sha);
            }
        } catch (Exception ignored) {
        }
    }

    private void rememberSynced(SharedPreferences prefs, long mtime, long size, String sha) {
        prefs.edit()
                .putLong(KEY_MTIME, mtime)
                .putLong(KEY_SIZE, size)
                .putString(KEY_SHA, sha)
                .apply();
    }

    private boolean uploadBackup(String serviceUrl, String token, byte[] bytes) {
        HttpURLConnection connection = null;
        try {
            URL base = new URL(serviceUrl.replaceAll("/+$", ""));
            URL target = new URL(base.toString() + "/v1/backup");
            connection = (HttpURLConnection) target.openConnection();
            connection.setRequestMethod("PUT");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(120000);
            connection.setUseCaches(false);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            if (token != null && !token.isEmpty()) connection.setRequestProperty("Authorization", "Bearer " + token);
            connection.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream output = connection.getOutputStream()) {
                output.write(bytes);
            }
            int status = connection.getResponseCode();
            return status >= 200 && status < 300;
        } catch (Exception ignored) {
            return false;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private File privateBackupFile() {
        return new File(new File(getFilesDir(), "backup"), BACKUP_FILE_NAME);
    }

    private byte[] readBytes(File file) {
        try (InputStream input = new FileInputStream(file); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[32768];
            int count;
            while ((count = input.read(buffer)) != -1) {
                output.write(buffer, 0, count);
            }
            return output.toByteArray();
        } catch (IOException ignored) {
            return null;
        }
    }

    private String sha256(byte[] bytes) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(bytes);
            StringBuilder sb = new StringBuilder(digest.length * 2);
            for (byte b : digest) sb.append(Character.forDigit((b >> 4) & 0xF, 16)).append(Character.forDigit(b & 0xF, 16));
            return sb.toString();
        } catch (Exception ignored) {
            return "";
        }
    }
}
